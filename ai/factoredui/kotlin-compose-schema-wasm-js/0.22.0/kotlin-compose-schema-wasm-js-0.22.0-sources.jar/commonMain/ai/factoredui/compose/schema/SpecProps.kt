package ai.factoredui.compose.schema

import ai.factoredui.compose.format.MISSING_FIGURE
import ai.factoredui.compose.format.dollarsText
import ai.factoredui.compose.format.feetInches
import ai.factoredui.compose.format.percentText
import ai.factoredui.compose.format.plainDecimalText
import ai.factoredui.compose.format.poundsText
import ai.factoredui.compose.ramp.RampReading
import ai.factoredui.compose.ramp.readColourRamp
import ai.factoredui.compose.stackedscene.ColourScale
import ai.factoredui.compose.stackedscene.ColourStop
import ai.factoredui.compose.stackedscene.SceneCamera
import ai.factoredui.compose.stackedscene.aspectOf
import ai.factoredui.compose.stackedscene.clampedZoom
import ai.factoredui.compose.stackedscene.LevelFocus
import ai.factoredui.compose.stackedscene.NEUTRAL_PART_COLOUR
import ai.factoredui.compose.stackedscene.StackedDrawing
import ai.factoredui.compose.stackedscene.YAxis
import ai.factoredui.compose.stackedscene.colourOfHex
import ai.factoredui.compose.stackedscene.stackedDrawingOf
import ai.factoredui.compose.stackedscene.yAxisOf

/**
 * Typed prop accessors for each SpecNodeType.
 *
 * The spec format stores all props as Map<String, SpecValue>. These helpers
 * extract typed values with safe defaults so the renderer doesn't need to cast.
 * Matches the prop interfaces in spec-types.ts.
 */

// --- Shared helpers ---

private fun Map<String, SpecValue>.string(key: String): String? =
    (get(key) as? SpecValue.StringValue)?.value

private fun Map<String, SpecValue>.stringOrDefault(key: String, default: String): String =
    string(key) ?: default

private fun Map<String, SpecValue>.int(key: String): Int? =
    (get(key) as? SpecValue.NumberValue)?.value?.toInt()

private fun Map<String, SpecValue>.double(key: String): Double? =
    (get(key) as? SpecValue.NumberValue)?.value

private fun Map<String, SpecValue>.boolean(key: String): Boolean? =
    (get(key) as? SpecValue.BooleanValue)?.value

// --- TextProps ---

data class TextProps(
    val value: String,
    val variant: TextVariant = TextVariant.BODY,
    val align: TextAlign = TextAlign.LEFT,
    val color: String? = null,
    val bold: Boolean = false,
    val numberOfLines: Int? = null,
    val formatName: String? = null,
    val missingText: String? = null,
)

enum class TextVariant { HEADING, SUBHEADING, BODY, CAPTION, LABEL }
enum class TextAlign { LEFT, CENTER, RIGHT }

fun Map<String, SpecValue>.asTextProps(): TextProps = TextProps(
    value = string("value") ?: "",
    variant = when (string("variant")) {
        "heading" -> TextVariant.HEADING
        "subheading" -> TextVariant.SUBHEADING
        "body" -> TextVariant.BODY
        "caption" -> TextVariant.CAPTION
        "label" -> TextVariant.LABEL
        else -> TextVariant.BODY
    },
    align = when (string("align")) {
        "center" -> TextAlign.CENTER
        "right" -> TextAlign.RIGHT
        else -> TextAlign.LEFT
    },
    color = string("color"),
    bold = boolean("bold") ?: false,
    numberOfLines = int("numberOfLines"),
    formatName = string("format"),
    missingText = string("missing"),
)

enum class TextFormat(val wire: String) { USD("usd"), FEET_INCHES("feet_inches"), PERCENT("percent"), POUNDS("pounds") }

fun textFormatOf(raw: Any?): TextFormat? = TextFormat.entries.firstOrNull { it.wire == raw }

internal fun figureOf(value: Any?): Double? = (value as? Number)?.toDouble()?.takeIf { it.isFinite() }

private fun unknownFormatNotice(rawFormat: Any) = "unknown format '$rawFormat'"

private fun notANumberNotice(value: Any, format: TextFormat) = "${format.wire} needs a number, not '$value'"

private const val MAX_EXACT_WHOLE = 9.0e15

internal fun plainFigureText(figure: Double): String = when {
    !figure.isFinite() -> figure.toString()
    figure % 1.0 == 0.0 && kotlin.math.abs(figure) < MAX_EXACT_WHOLE -> figure.toLong().toString()
    else -> plainDecimalText(figure)
}

private fun unformattedText(value: Any?, missingText: String?): String = when (value) {
    null -> missingText ?: ""
    is String -> value
    is Number -> figureOf(value)?.let(::plainFigureText) ?: value.toString()
    else -> ""
}

fun displayedText(value: Any?, rawFormat: Any?, missingText: String?): String {
    if (rawFormat == null) return unformattedText(value, missingText)
    if (rawFormat is Map<*, *>) return objectFormattedText(value, rawFormat, missingText)
    val format = textFormatOf(rawFormat) ?: return unknownFormatNotice(rawFormat)
    return formattedFigure(value, format, missingText)
}

fun formattedFigure(value: Any?, format: TextFormat, missingText: String? = null): String {
    if (value == null) return missingText ?: MISSING_FIGURE
    val figure = figureOf(value) ?: return notANumberNotice(value, format)
    return when (format) {
        TextFormat.USD -> dollarsText(figure)
        TextFormat.FEET_INCHES -> feetInches(figure)
        TextFormat.PERCENT -> percentText(figure)
        TextFormat.POUNDS -> poundsText(figure)
    }
}

// --- ButtonProps ---

data class ButtonProps(
    val label: String,
    val variant: ButtonVariant = ButtonVariant.PRIMARY,
    val size: ButtonSize = ButtonSize.MD,
    val icon: String? = null,
    val disabled: Boolean = false,
)

enum class ButtonVariant { PRIMARY, SECONDARY, OUTLINE, GHOST, DESTRUCTIVE }
enum class ButtonSize { SM, MD, LG, XL }

fun Map<String, SpecValue>.asButtonProps(): ButtonProps = ButtonProps(
    label = string("label") ?: "",
    variant = when (string("variant")) {
        "secondary" -> ButtonVariant.SECONDARY
        "outline" -> ButtonVariant.OUTLINE
        "ghost" -> ButtonVariant.GHOST
        "destructive" -> ButtonVariant.DESTRUCTIVE
        else -> ButtonVariant.PRIMARY
    },
    size = when (string("size")) {
        "sm" -> ButtonSize.SM
        "lg" -> ButtonSize.LG
        "xl" -> ButtonSize.XL
        else -> ButtonSize.MD
    },
    icon = string("icon"),
    disabled = boolean("disabled") ?: false,
)

// --- LayoutProps ---

data class LayoutProps(
    val gap: Int = 0,
    val padding: Int = 0,
    val align: LayoutAlign = LayoutAlign.START,
    val justify: LayoutJustify = LayoutJustify.START,
    val flex: Float = 0f,
    val background: String? = null,
    val width: Float? = null,
    val height: Float? = null,
    val sizeFaults: List<String> = emptyList(),
)

enum class LayoutAlign { START, CENTER, END, STRETCH }
enum class LayoutJustify { START, CENTER, END, BETWEEN, AROUND }

fun Map<String, SpecValue>.asLayoutProps(): LayoutProps {
    val width = slotSizeOf("width", get("width"))
    val height = slotSizeOf("height", get("height"))
    return layoutPropsOf(width, height)
}

private fun Map<String, SpecValue>.layoutPropsOf(width: SlotSize, height: SlotSize): LayoutProps = LayoutProps(
    background = string("background"),
    gap = int("gap") ?: 0,
    padding = int("padding") ?: 0,
    align = when (string("align")) {
        "center" -> LayoutAlign.CENTER
        "end" -> LayoutAlign.END
        "stretch" -> LayoutAlign.STRETCH
        else -> LayoutAlign.START
    },
    justify = when (string("justify")) {
        "center" -> LayoutJustify.CENTER
        "end" -> LayoutJustify.END
        "between" -> LayoutJustify.BETWEEN
        "around" -> LayoutJustify.AROUND
        else -> LayoutJustify.START
    },
    flex = double("flex")?.toFloat() ?: 0f,
    width = width.dp?.toFloat(),
    height = height.dp?.toFloat(),
    sizeFaults = listOfNotNull(width.fault, height.fault),
)

// --- ImageProps ---

data class ImageProps(
    val source: String,
    val alt: String = "",
    val fit: ImageFit = ImageFit.COVER,
    val aspectRatio: Float? = null,
)

enum class ImageFit { COVER, CONTAIN, FILL }

fun Map<String, SpecValue>.asImageProps(): ImageProps = ImageProps(
    source = string("source") ?: "",
    alt = string("alt") ?: "",
    fit = when (string("fit")) {
        "contain" -> ImageFit.CONTAIN
        "fill" -> ImageFit.FILL
        else -> ImageFit.COVER
    },
    aspectRatio = double("aspectRatio")?.toFloat(),
)

// --- VideoProps ---

data class VideoProps(
    val source: String,
    val autoplay: Boolean = false,
    val loop: Boolean = false,
    val position: Double? = null,
    val aspectRatio: Float? = null,
)

fun Map<String, SpecValue>.asVideoProps(): VideoProps = VideoProps(
    source = string("source") ?: "",
    autoplay = boolean("autoplay") ?: false,
    loop = boolean("loop") ?: false,
    position = double("position"),
    aspectRatio = double("aspectRatio")?.toFloat(),
)

// --- IconProps ---

data class IconProps(
    val name: String,
    val size: Int = 24,
    val color: String? = null,
)

fun Map<String, SpecValue>.asIconProps(): IconProps = IconProps(
    name = string("name") ?: "",
    size = int("size") ?: 24,
    color = string("color"),
)

// --- ListProps ---

data class ListProps(
    val data: String,
    /**
     * Live query resolved by the host's HostDataSource, e.g.
     * "query:automations:approved_at_ms IS NULL". When set (and the host wires
     * a HostDataSource into the RenderContext), the list subscribes to a Flow
     * of result sets and re-renders on every change. When null, the list reads
     * the static [data] key against the render context — behaviour is unchanged.
     * The string is opaque to the renderer; only the host's storage layer
     * interprets it.
     */
    val dataSource: String?,
    val itemTemplate: SpecNode?,
    val emptyText: String = "",
    val maxItems: Int? = null,
    val stacked: Boolean = false,
    val where: SpecValue? = null,
    val order: SpecValue? = null,
    val rowName: String? = null,
)

fun Map<String, SpecValue>.asListProps(): ListProps = ListProps(
    rowName = string("row_name"),
    where = get("where"),
    order = get("order"),
    data = string("data") ?: "",
    dataSource = string("data_source"),
    itemTemplate = (get("itemTemplate") as? SpecValue.NodeValue)?.value,
    emptyText = string("emptyText") ?: "",
    maxItems = int("maxItems"),
    stacked = boolean("stacked") ?: false,
)

// --- SpacerProps ---

data class SpacerProps(
    val size: Int = 0,
    val flex: Float = 0f,
)

fun Map<String, SpecValue>.asSpacerProps(): SpacerProps = SpacerProps(
    size = int("size") ?: 0,
    flex = double("flex")?.toFloat() ?: 0f,
)

// --- GridProps ---

/**
 * `lazy` opts into LazyVerticalGrid (windowed rendering, supports thousands of
 * items). Off by default because LazyVerticalGrid requires a bounded height —
 * dropping it inside an unbounded scrollview throws at runtime. Spec authors
 * with large item counts should set `lazy: true` and ensure the grid sits in
 * a height-bounded container (e.g. fillMaxSize, or a sized parent).
 */
data class GridProps(
    val columns: Int = 2,
    val gap: Int = 0,
    val lazy: Boolean = false,
)

fun Map<String, SpecValue>.asGridProps(): GridProps = GridProps(
    columns = int("columns") ?: 2,
    gap = int("gap") ?: 0,
    lazy = boolean("lazy") ?: false,
)

// --- ToggleProps ---

data class ToggleProps(
    val label: String = "",
    val color: String? = null,
)

fun Map<String, SpecValue>.asToggleProps(): ToggleProps = ToggleProps(
    label = string("label") ?: "",
    color = string("color"),
)

// --- StackPlacement ---

enum class StackAnchor { FILL, TOP, BOTTOM, END }

data class StackPlacement(val anchor: StackAnchor? = null)

/** Where a child of a `stack` sits: `anchor` is `fill`, `top`, `bottom` or `end`. */
fun Map<String, SpecValue>.asStackPlacement(): StackPlacement = StackPlacement(
    anchor = when (string("anchor")) {
        "fill" -> StackAnchor.FILL
        "top" -> StackAnchor.TOP
        "bottom" -> StackAnchor.BOTTOM
        "end" -> StackAnchor.END
        else -> null
    },
)

fun Map<String, SpecValue>.fillsParent(): Boolean = boolean("fill") ?: false

// --- SliderProps ---

data class SliderProps(
    val min: Float = 0f,
    val max: Float = 1f,
    val step: Float? = null,
)

fun Map<String, SpecValue>.asSliderProps(): SliderProps = SliderProps(
    min = double("min")?.toFloat() ?: 0f,
    max = double("max")?.toFloat() ?: 1f,
    step = double("step")?.toFloat(),
)

// --- SelectProps ---

/** [value] is the option's JSON value (text, number or bool); [key] is its canonical text, which matches a bound value and names it on the control port. */
data class SelectOption(val label: String, val value: Any, val key: String)

data class SelectProps(
    val options: List<SelectOption> = emptyList(),
    val placeholder: String = "",
    val droppedOptionIndices: List<Int> = emptyList(),
)

fun selectOptionKeyOf(value: Any?): String? = when (value) {
    is String -> value
    is Boolean -> value.toString()
    is Number -> figureOf(value)?.let(::plainFigureText)
    else -> null
}

private fun SpecValue.selectOptionValue(): Any? = when (this) {
    is SpecValue.StringValue -> value
    is SpecValue.NumberValue -> value
    is SpecValue.BooleanValue -> value
    else -> null
}

private fun selectOptionOf(item: SpecValue): SelectOption? {
    val obj = (item as? SpecValue.ObjectValue)?.value ?: return null
    val label = obj.string("label") ?: return null
    val value = obj["value"]?.selectOptionValue() ?: return null
    val key = selectOptionKeyOf(value) ?: return null
    return SelectOption(label = label, value = value, key = key)
}

fun Map<String, SpecValue>.asSelectProps(): SelectProps {
    val rawOptions = (get("options") as? SpecValue.ArrayValue)?.value ?: emptyList()
    val read = rawOptions.map(::selectOptionOf)
    return SelectProps(
        options = read.filterNotNull(),
        placeholder = string("placeholder") ?: "",
        droppedOptionIndices = read.indices.filter { read[it] == null },
    )
}

// --- TabsProps ---

data class TabsProps(
    val items: List<String> = emptyList(),
)

fun Map<String, SpecValue>.asTabsProps(): TabsProps {
    val raw = (get("items") as? SpecValue.ArrayValue)?.value ?: emptyList()
    return TabsProps(
        items = raw.mapNotNull { (it as? SpecValue.StringValue)?.value },
    )
}

// --- ModalProps ---

data class ModalProps(
    val title: String = "",
    val dismissible: Boolean = true,
)

fun Map<String, SpecValue>.asModalProps(): ModalProps = ModalProps(
    title = string("title") ?: "",
    dismissible = boolean("dismissible") ?: true,
)

// --- Scene3dProps ---
// Second "dense/semantic" primitive; full contract in spec-types.ts. Entities,
// camera, and lights live in the fetched world state, not in spec props.

data class Scene3dProps(
    val worldStateUrl: String,
    val worldStreamUrl: String? = null,
    val actionUrl: String? = null,
    val background: String = "neutral-gray",
    val clipUrl: String? = null,
    val clipUrlB: String? = null,
    val clipFrame: Int = 0,
    val clipFrameFraction: Float = 0f,
    val clipImpulse: Float = 0.8f,
    val clipAutoplay: Boolean = false,
    val clipSeverity: Float = 0f,
    val clipEffector: String = "R_Hand",
    val board: String? = null,
    val engineUrl: String? = null,
    val engine: String = "injury",
    val simId: String? = null,
    val bodyFrame: String? = null,
    val chrome: Boolean = true,
)

fun Map<String, SpecValue>.asScene3dProps(): Scene3dProps = Scene3dProps(
    worldStateUrl = string("world_state_url") ?: "",
    worldStreamUrl = string("world_stream_url"),
    actionUrl = string("action_url"),
    background = string("background") ?: "neutral-gray",
    clipUrl = string("clip_url"),
    clipUrlB = string("clip_url_b"),
    clipFrame = (double("frame") ?: 0.0).toInt(),
    clipFrameFraction = (double("frame") ?: 0.0).toFloat(),
    clipImpulse = (double("impulse") ?: 0.8).toFloat(),
    board = string("board"),
    engineUrl = string("engine_url"),
    engine = string("engine") ?: "injury",
    simId = string("sim_id"),
    bodyFrame = string("body_frame"),
    chrome = boolean("chrome") ?: true,
)

data class CanvasEdge(val from: String, val to: String)

data class CanvasPathPoint(val x: Float, val y: Float)

data class CanvasPath(val id: String, val color: String, val points: List<CanvasPathPoint>)

const val DEFAULT_PATH_COLOR = "#8A94AD"

const val TRAIL_MIN_ALPHA = 0.08f

fun trailSegmentAlpha(segmentIndex: Int, segmentCount: Int): Float {
    if (segmentCount <= 0) return 1f
    val headFraction = (segmentIndex + 1).toFloat() / segmentCount
    return TRAIL_MIN_ALPHA + (1f - TRAIL_MIN_ALPHA) * headFraction
}

data class CanvasViewport(val x: Float, val y: Float, val zoom: Float)

val IDENTITY_VIEWPORT = CanvasViewport(0f, 0f, 1f)

data class CanvasProps(
    val edges: List<CanvasEdge> = emptyList(),
    val nodesBinding: String? = null,
    val edgesBinding: String? = null,
    val pathsBinding: String? = null,
    val viewportBinding: String? = null,
    val onNodeArranged: String? = null,
    val onNodeTapped: String? = null,
    val onViewportChanged: String? = null,
)

fun Map<String, SpecValue>.asCanvasProps(): CanvasProps = CanvasProps(
    edges = (get("edges") as? SpecValue.ArrayValue)?.value.orEmpty().mapNotNull { edge ->
        val fields = (edge as? SpecValue.ObjectValue)?.value ?: return@mapNotNull null
        val from = fields.string("from") ?: return@mapNotNull null
        val to = fields.string("to") ?: return@mapNotNull null
        CanvasEdge(from, to)
    },
    nodesBinding = string("nodes"),
    edgesBinding = string("edges"),
    pathsBinding = string("paths"),
    viewportBinding = string("viewport"),
    onNodeArranged = string("on_node_arranged"),
    onNodeTapped = string("on_node_tap"),
    onViewportChanged = string("on_viewport_changed"),
)

// --- GeomapProps ---

data class GeoPoint(val lon: Double, val lat: Double)

enum class GeomapLayerKind(val fewestPoints: Int) { FILL(3), LINE(2), POINT(1) }

enum class GeomapPatternKind { HATCH, CROSS, DOTS }

data class GeomapPattern(
    val kind: GeomapPatternKind,
    val color: String,
    val angle: Float = 45f,
    val spacing: Float = 8f,
    val lineWidth: Float = 2.5f,
    val background: String? = null,
)

data class GeomapFeature(
    val id: String,
    val rings: List<List<GeoPoint>>,
    val fill: String? = null,
    val stroke: String? = null,
    val strokeWidth: Float = 1f,
    val label: String? = null,
    val pattern: GeomapPattern? = null,
    val dash: List<Float>? = null,
    val geometryId: String? = null,
    val radius: Float = DEFAULT_POINT_RADIUS,
    val values: Map<String, Double?> = emptyMap(),
    val info: Map<String, Any> = emptyMap(),
    val figures: Map<String, Double?> = emptyMap(),
)

const val DEFAULT_POINT_RADIUS = 5f

data class GeomapLegendEntry(
    val label: String,
    val fill: String? = null,
    val pattern: GeomapPattern? = null,
    val layer: String? = null,
)

data class GeomapLayer(
    val id: String,
    val kind: GeomapLayerKind,
    val features: List<GeomapFeature>,
    val visible: Boolean = true,
    val minZoom: Float? = null,
    val maxZoom: Float? = null,
)

const val DEFAULT_TILE_SIZE = 256
const val DEFAULT_TILE_MAX_ZOOM = 18
private const val HIGHEST_TILE_ZOOM = 30
private val TILE_PLACEHOLDERS = listOf("[z]", "[x]", "[y]")

/** A layer of map tiles drawn under the vector layers. The template names its own order with [z], [x] and [y]; braces would be taken for bindings and emptied before the layer sees them. */
data class GeomapRasterLayer(
    val id: String,
    val urlTemplate: String,
    val tileSize: Int = DEFAULT_TILE_SIZE,
    val tileMaxZoom: Int = DEFAULT_TILE_MAX_ZOOM,
    val attribution: String? = null,
    val visible: Boolean = true,
    val minZoom: Float? = null,
    val maxZoom: Float? = null,
)

private fun rasterEntries(resolvedLayers: Any?): List<Map<*, *>> =
    (resolvedLayers as? List<*>).orEmpty().mapNotNull { entry -> (entry as? Map<*, *>)?.takeIf { it["kind"] == "raster" } }

private fun rasterProblem(entry: Map<*, *>): String? {
    val id = entry["id"] as? String ?: return "a raster layer has no id"
    val template = entry["url"] as? String ?: return "raster layer '$id' has no url"
    val missing = TILE_PLACEHOLDERS.filter { it !in template }
    if (missing.isNotEmpty()) return "raster layer '$id' url lacks ${missing.joinToString(", ")} (square brackets: a {z} in braces is replaced as a binding)"
    val size = entry["tile_size"]
    if (size != null && ((size as? Number)?.toInt() ?: 0) <= 0) return "raster layer '$id' has a tile_size that is not a positive whole number"
    return null
}

/** One line for each raster layer entry that cannot be drawn, so a spec author sees why a basemap is missing. */
fun geomapRasterProblems(resolvedLayers: Any?): List<String> = rasterEntries(resolvedLayers).mapNotNull(::rasterProblem)

fun resolveGeomapRasterLayers(resolvedLayers: Any?): List<GeomapRasterLayer> =
    rasterEntries(resolvedLayers).filter { rasterProblem(it) == null }.map { entry ->
        GeomapRasterLayer(
            id = entry["id"] as String,
            urlTemplate = entry["url"] as String,
            tileSize = (entry["tile_size"] as? Number)?.toInt() ?: DEFAULT_TILE_SIZE,
            tileMaxZoom = ((entry["tile_max_zoom"] as? Number)?.toInt() ?: DEFAULT_TILE_MAX_ZOOM).coerceIn(0, HIGHEST_TILE_ZOOM),
            attribution = (entry["attribution"] as? String)?.takeIf { it.isNotBlank() },
            visible = entry["visible"] as? Boolean ?: true,
            minZoom = (entry["min_zoom"] as? Number)?.toFloat(),
            maxZoom = (entry["max_zoom"] as? Number)?.toFloat(),
        )
    }

data class GeomapViewport(val lon: Double, val lat: Double, val zoom: Float)

data class GeomapProps(
    val onFeatureTap: String? = null,
    val onViewportChanged: String? = null,
)

fun Map<String, SpecValue>.asGeomapProps(): GeomapProps = GeomapProps(
    onFeatureTap = string("on_feature_tap"),
    onViewportChanged = string("on_viewport_changed"),
)

fun resolveGeomapSelection(resolvedSelected: Any?): Set<String> =
    (resolvedSelected as? List<*>).orEmpty().filterIsInstance<String>().toSet()

fun selectionAfterTap(selection: Set<String>, tappedId: String?): List<String> = when {
    tappedId == null -> emptyList()
    selection == setOf(tappedId) -> emptyList()
    else -> listOf(tappedId)
}

fun resolveGeomapGeometries(resolvedGeometries: Any?): Map<String, List<List<GeoPoint>>> =
    (resolvedGeometries as? Map<*, *>).orEmpty().mapNotNull { (key, rings) ->
        val id = key as? String ?: return@mapNotNull null
        val resolved = resolveGeomapRings(rings, GeomapLayerKind.LINE.fewestPoints)
        if (resolved.isEmpty()) null else id to resolved
    }.toMap()

fun resolveGeomapLayers(resolvedLayers: Any?, resolvedGeometries: Any? = null): List<GeomapLayer> {
    val geometries = resolveGeomapGeometries(resolvedGeometries)
    return (resolvedLayers as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val id = fields["id"] as? String ?: return@mapNotNull null
        if (fields["kind"] == "raster") return@mapNotNull null
        val kind = when (fields["kind"]) {
            "line" -> GeomapLayerKind.LINE
            "point" -> GeomapLayerKind.POINT
            else -> GeomapLayerKind.FILL
        }
        GeomapLayer(
            id = id,
            kind = kind,
            features = resolveGeomapFeatures(fields["features"], geometries, kind),
            visible = fields["visible"] as? Boolean ?: true,
            minZoom = (fields["min_zoom"] as? Number)?.toFloat(),
            maxZoom = (fields["max_zoom"] as? Number)?.toFloat(),
        )
    }
}

fun unresolvedGeometryRefs(resolvedLayers: Any?, resolvedGeometries: Any?): List<String> {
    val known = resolveGeomapGeometries(resolvedGeometries).keys
    return (resolvedLayers as? List<*>).orEmpty()
        .flatMap { layer -> ((layer as? Map<*, *>)?.get("features") as? List<*>).orEmpty() }
        .mapNotNull { feature -> (feature as? Map<*, *>)?.get("geometry") as? String }
        .filterNot { it in known }
        .distinct()
}

private fun resolveGeomapFeatures(
    resolvedFeatures: Any?,
    geometries: Map<String, List<List<GeoPoint>>>,
    kind: GeomapLayerKind,
): List<GeomapFeature> =
    (resolvedFeatures as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val id = fields["id"] as? String ?: return@mapNotNull null
        val geometryId = fields["geometry"] as? String
        val rings = when {
            geometryId != null -> geometries[geometryId].orEmpty()
            kind == GeomapLayerKind.POINT -> listOfNotNull(resolveGeoPoint(fields["point"])?.let(::listOf))
            else -> resolveGeomapRings(fields["rings"], kind.fewestPoints)
        }
        if (rings.isEmpty()) return@mapNotNull null
        GeomapFeature(
            id = id,
            rings = rings,
            fill = fields["fill"] as? String,
            stroke = fields["stroke"] as? String,
            strokeWidth = (fields["stroke_width"] as? Number)?.toFloat() ?: 1f,
            label = fields["label"] as? String,
            pattern = resolveGeomapPattern(fields["pattern"]),
            dash = (fields["dash"] as? List<*>)?.mapNotNull { (it as? Number)?.toFloat() }?.takeIf { it.size >= 2 },
            geometryId = geometryId,
            radius = (fields["radius"] as? Number)?.toFloat() ?: DEFAULT_POINT_RADIUS,
            values = resolveGeomapValues(fields["values"]),
            info = resolveGeomapInfo(fields["info"]),
            figures = resolveGeomapValues(fields["figures"]),
        )
    }

private fun resolveGeomapInfo(resolvedInfo: Any?): Map<String, Any> =
    (resolvedInfo as? Map<*, *>).orEmpty().mapNotNull { (key, value) ->
        val name = key as? String ?: return@mapNotNull null
        val scalar = value?.takeIf { it is String || it is Number || it is Boolean } ?: return@mapNotNull null
        name to scalar
    }.toMap()

private fun resolveGeomapValues(resolvedValues: Any?): Map<String, Double?> =
    (resolvedValues as? Map<*, *>).orEmpty().mapNotNull { (key, value) ->
        (key as? String)?.let { name -> name to (value as? Number)?.toDouble()?.takeIf { it.isFinite() } }
    }.toMap()

fun resolveGeomapPattern(resolvedPattern: Any?): GeomapPattern? {
    val fields = resolvedPattern as? Map<*, *> ?: return null
    val color = fields["color"] as? String ?: return null
    val kind = when (fields["kind"]) {
        "cross" -> GeomapPatternKind.CROSS
        "dots" -> GeomapPatternKind.DOTS
        else -> GeomapPatternKind.HATCH
    }
    return GeomapPattern(
        kind = kind,
        color = color,
        angle = (fields["angle"] as? Number)?.toFloat() ?: 45f,
        spacing = (fields["spacing"] as? Number)?.toFloat() ?: 8f,
        lineWidth = (fields["line_width"] as? Number)?.toFloat() ?: 2.5f,
        background = fields["background"] as? String,
    )
}

fun resolveGeomapLegend(resolvedLegend: Any?): List<GeomapLegendEntry> =
    (resolvedLegend as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val label = fields["label"] as? String ?: return@mapNotNull null
        GeomapLegendEntry(
            label = label,
            fill = fields["fill"] as? String,
            pattern = resolveGeomapPattern(fields["pattern"]),
            layer = fields["layer"] as? String,
        )
    }

private fun resolveGeoPoint(resolvedPoint: Any?): GeoPoint? {
    val pair = resolvedPoint as? List<*> ?: return null
    val lon = (pair.getOrNull(0) as? Number)?.toDouble() ?: return null
    val lat = (pair.getOrNull(1) as? Number)?.toDouble() ?: return null
    return GeoPoint(lon, lat)
}

private fun resolveGeomapRings(resolvedRings: Any?, fewestPoints: Int = GeomapLayerKind.FILL.fewestPoints): List<List<GeoPoint>> {
    val outer = resolvedRings as? List<*> ?: return emptyList()
    val first = outer.firstOrNull() as? List<*> ?: return emptyList()
    val isSingleRingOfPairs = first.firstOrNull() is Number
    val ringLists: List<*> = if (isSingleRingOfPairs) listOf(outer) else outer
    return ringLists.mapNotNull { ring ->
        val points = (ring as? List<*>).orEmpty().mapNotNull(::resolveGeoPoint)
        if (points.size >= fewestPoints) points else null
    }
}

/** `margin` is the share (above 0, up to 1) of the free map the box may fill; `insetBottomDp` is a strip along the bottom that something else (a sheet) covers. */
data class GeomapBoundsRequest(
    val minLon: Double,
    val minLat: Double,
    val maxLon: Double,
    val maxLat: Double,
    val margin: Double? = null,
    val insetBottomDp: Double = 0.0,
)

fun resolveGeomapBoundsRequest(resolvedViewport: Any?): GeomapBoundsRequest? {
    val fields = resolvedViewport as? Map<*, *> ?: return null
    val corners = (fields["bounds"] as? List<*>)?.mapNotNull { (it as? Number)?.toDouble() } ?: return null
    if (corners.size != 4) return null
    val margin = (fields["margin"] as? Number)?.toDouble()?.takeIf { it > 0.0 && it <= 1.0 }
    val inset = (fields["inset_bottom"] as? Number)?.toDouble()?.takeIf { it >= 0.0 } ?: 0.0
    return GeomapBoundsRequest(corners[0], corners[1], corners[2], corners[3], margin, inset)
}

fun resolveGeomapViewport(resolvedViewport: Any?): GeomapViewport? {
    val fields = resolvedViewport as? Map<*, *> ?: return null
    val lon = (fields["lon"] as? Number)?.toDouble() ?: return null
    val lat = (fields["lat"] as? Number)?.toDouble() ?: return null
    return GeomapViewport(
        lon = lon,
        lat = lat,
        zoom = (fields["zoom"] as? Number)?.toFloat() ?: 12f,
    )
}

data class FieldNodeEntry(
    val id: String,
    val x: Float,
    val y: Float,
    val glow: Float,
    val label: String,
)

fun resolveFieldNodeEntries(resolvedNodes: Any?): List<FieldNodeEntry> =
    (resolvedNodes as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val id = fields["id"] as? String ?: return@mapNotNull null
        FieldNodeEntry(
            id = id,
            x = (fields["x"] as? Number)?.toFloat() ?: 0f,
            y = (fields["y"] as? Number)?.toFloat() ?: 0f,
            glow = (fields["glow"] as? Number)?.toFloat() ?: 1f,
            label = fields["label"] as? String ?: id,
        )
    }

fun resolveCanvasEdges(resolvedEdges: Any?): List<CanvasEdge> =
    (resolvedEdges as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val from = fields["from"] as? String ?: return@mapNotNull null
        val to = fields["to"] as? String ?: return@mapNotNull null
        CanvasEdge(from, to)
    }

fun resolveCanvasPaths(resolvedPaths: Any?): List<CanvasPath> =
    (resolvedPaths as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val id = fields["id"] as? String ?: return@mapNotNull null
        CanvasPath(
            id = id,
            color = fields["color"] as? String ?: DEFAULT_PATH_COLOR,
            points = resolveCanvasPathPoints(fields["points"]),
        )
    }

private fun resolveCanvasPathPoints(resolvedPoints: Any?): List<CanvasPathPoint> =
    (resolvedPoints as? List<*>).orEmpty().mapNotNull { point ->
        val fields = point as? Map<*, *> ?: return@mapNotNull null
        val x = (fields["x"] as? Number)?.toFloat() ?: return@mapNotNull null
        val y = (fields["y"] as? Number)?.toFloat() ?: return@mapNotNull null
        CanvasPathPoint(x, y)
    }

fun resolveCanvasViewport(resolvedViewport: Any?): CanvasViewport {
    val fields = resolvedViewport as? Map<*, *> ?: return IDENTITY_VIEWPORT
    val zoom = (fields["zoom"] as? Number)?.toFloat() ?: 1f
    return CanvasViewport(
        x = (fields["x"] as? Number)?.toFloat() ?: 0f,
        y = (fields["y"] as? Number)?.toFloat() ?: 0f,
        zoom = if (zoom > 0f) zoom else 1f,
    )
}

const val MIN_CANVAS_ZOOM = 0.2f
const val MAX_CANVAS_ZOOM = 12f

data class ViewportTransform(val translationX: Float, val translationY: Float, val scale: Float)

fun CanvasViewport.transformFor(widthPx: Float, heightPx: Float): ViewportTransform =
    ViewportTransform(translationX = -x * zoom * widthPx, translationY = -y * zoom * heightPx, scale = zoom)

fun CanvasViewport.afterTransformGesture(
    centroidXpx: Float,
    centroidYpx: Float,
    panXpx: Float,
    panYpx: Float,
    zoomDelta: Float,
    widthPx: Float,
    heightPx: Float,
): CanvasViewport {
    val newZoom = (zoom * zoomDelta).coerceIn(MIN_CANVAS_ZOOM, MAX_CANVAS_ZOOM)
    val worldX = centroidXpx / (zoom * widthPx) + x
    val worldY = centroidYpx / (zoom * heightPx) + y
    return CanvasViewport(
        x = worldX - (centroidXpx + panXpx) / (newZoom * widthPx),
        y = worldY - (centroidYpx + panYpx) / (newZoom * heightPx),
        zoom = newZoom,
    )
}

// --- GraphProps ---

enum class GraphNodeShape { BOX, PILL }

data class GraphNodeEntry(
    val id: String,
    val label: String,
    val group: String? = null,
    val status: String? = null,
    val kind: String? = null,
    val shape: GraphNodeShape? = null,
    val color: String? = null,
    val rank: Int? = null,
    val x: Float? = null,
    val y: Float? = null,
    val selfLoop: Boolean = false,
)

data class GraphKindStyle(
    val shape: GraphNodeShape? = null,
    val compact: Boolean = false,
    val muted: Boolean = false,
    val borderWidth: Float? = null,
)

data class GraphEdgeEntry(
    val from: String,
    val to: String,
    val kind: String? = null,
    val status: String? = null,
    val color: String? = null,
    val dash: Boolean = false,
    val marker: String? = null,
)

data class GraphLegendEntry(
    val label: String,
    val kind: String,
    val color: String? = null,
    val outline: String? = null,
    val shape: GraphNodeShape? = null,
    val compact: Boolean = false,
    val muted: Boolean = false,
    val borderWidth: Float? = null,
    val dash: Boolean = false,
    val marker: String? = null,
    val icon: String? = null,
)

data class GraphProps(val onNodeTapped: String? = null, val onEdgeTapped: String? = null)

fun Map<String, SpecValue>.asGraphProps(): GraphProps =
    GraphProps(onNodeTapped = string("on_node_tap"), onEdgeTapped = string("on_edge_tap"))

private val GRAPH_LEGEND_KINDS = setOf("node", "edge", "badge")

fun resolveGraphLegend(resolvedLegend: Any?): List<GraphLegendEntry> =
    (resolvedLegend as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val label = fields["label"] as? String ?: return@mapNotNull null
        val kind = (fields["kind"] as? String)?.takeIf { it in GRAPH_LEGEND_KINDS } ?: return@mapNotNull null
        GraphLegendEntry(
            label = label,
            kind = kind,
            color = fields["color"] as? String,
            outline = fields["outline"] as? String,
            shape = graphShapeOf(fields["shape"]),
            compact = fields["compact"] as? Boolean ?: false,
            muted = fields["muted"] as? Boolean ?: false,
            borderWidth = (fields["border_width"] as? Number)?.toFloat(),
            dash = fields["dash"] as? Boolean ?: false,
            marker = fields["marker"] as? String,
            icon = fields["icon"] as? String,
        )
    }

private const val MIN_GRAPH_ZOOM = 0.2f
private const val MAX_GRAPH_ZOOM = 8f

fun resolveGraphZoom(resolvedZoom: Any?): Float =
    (resolvedZoom as? Number)?.toFloat()?.coerceIn(MIN_GRAPH_ZOOM, MAX_GRAPH_ZOOM) ?: 1f

fun resolveGraphNodes(resolvedNodes: Any?): List<GraphNodeEntry> =
    (resolvedNodes as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val id = fields["id"] as? String ?: return@mapNotNull null
        GraphNodeEntry(
            id = id,
            label = fields["label"] as? String ?: id,
            group = fields["group"] as? String,
            status = fields["status"] as? String,
            kind = fields["kind"] as? String,
            shape = graphShapeOf(fields["shape"]),
            color = fields["color"] as? String,
            rank = (fields["rank"] as? Number)?.toInt(),
            x = (fields["x"] as? Number)?.toFloat(),
            y = (fields["y"] as? Number)?.toFloat(),
            selfLoop = fields["self_loop"] as? Boolean ?: false,
        )
    }

private fun graphShapeOf(raw: Any?): GraphNodeShape? = when (raw as? String) {
    "pill" -> GraphNodeShape.PILL
    "box" -> GraphNodeShape.BOX
    else -> null
}

fun resolveGraphKindStyles(resolvedStyles: Any?): Map<String, GraphKindStyle> =
    (resolvedStyles as? Map<*, *>).orEmpty().mapNotNull { (key, value) ->
        val kind = key as? String ?: return@mapNotNull null
        val fields = value as? Map<*, *> ?: return@mapNotNull null
        kind to GraphKindStyle(
            shape = graphShapeOf(fields["shape"]),
            compact = fields["compact"] as? Boolean ?: false,
            muted = fields["muted"] as? Boolean ?: false,
            borderWidth = (fields["border_width"] as? Number)?.toFloat(),
        )
    }.toMap()

fun resolveGraphEdges(resolvedEdges: Any?): List<GraphEdgeEntry> =
    (resolvedEdges as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val from = fields["from"] as? String ?: return@mapNotNull null
        val to = fields["to"] as? String ?: return@mapNotNull null
        GraphEdgeEntry(
            from = from,
            to = to,
            kind = fields["kind"] as? String,
            status = fields["status"] as? String,
            color = fields["color"] as? String,
            dash = fields["dash"] as? Boolean ?: false,
            marker = fields["marker"] as? String,
        )
    }

fun resolveGraphGroupOrder(resolvedOrder: Any?): List<String> =
    (resolvedOrder as? List<*>).orEmpty().filterIsInstance<String>()

fun resolveGraphStringMap(resolved: Any?): Map<String, String> =
    (resolved as? Map<*, *>).orEmpty().mapNotNull { (key, value) ->
        val name = key as? String ?: return@mapNotNull null
        val hex = value as? String ?: return@mapNotNull null
        name to hex
    }.toMap()

private val GRAPH_PALETTE = listOf(
    "#3FA34D", "#4C78C9", "#D98E04", "#C0392B", "#8E5BC9", "#1F9DA8", "#B5651D", "#6B7A8F",
)

fun assignGraphColors(keys: List<String>, explicit: Map<String, String>): Map<String, String> {
    val distinct = keys.distinct()
    val needsPalette = distinct.filter { it !in explicit }
    val fromPalette = needsPalette.withIndex().associate { (index, key) -> key to GRAPH_PALETTE[index % GRAPH_PALETTE.size] }
    return distinct.associateWith { explicit[it] ?: fromPalette.getValue(it) }
}

// --- Stacked scene props (scene node, view_state.renderer == "stacked_scene") ---

private const val ALL_LEVELS = "all"

/** [notes] name every prop the renderer could not read, so the screen says what it fell back to. */
data class StackedSceneProps(
    val drawing: StackedDrawing = StackedDrawing.PLAN,
    val focus: LevelFocus = LevelFocus.AllLevels,
    val showLower: Boolean = false,
    val hideTopCount: Int = 0,
    val highlightIds: Set<String> = emptySet(),
    val onPartTap: String? = null,
    val colourScale: ColourScale? = null,
    val notes: List<String> = emptyList(),
    val yAxis: YAxis? = null,
    val activeScheme: String? = null,
    val quarterTurns: Int = 0,
    val camera: SceneCamera = SceneCamera(),
)

private data class PropReading<T>(val value: T, val note: String? = null)

private fun wholeNumberOf(raw: Any?): Int? =
    (raw as? Number)?.toDouble()?.takeIf { it % 1.0 == 0.0 && it >= Int.MIN_VALUE && it <= Int.MAX_VALUE }?.toInt()

private fun drawingReading(raw: Any?): PropReading<StackedDrawing> {
    if (raw == null) return PropReading(StackedDrawing.PLAN)
    val drawing = stackedDrawingOf(raw) ?: return PropReading(StackedDrawing.PLAN, "view '$raw' is not plan, iso, south or west; the plan is drawn.")
    return PropReading(drawing)
}

private fun yAxisReading(raw: Any?): PropReading<YAxis?> {
    if (raw == null) return PropReading(null)
    val yAxis = yAxisOf(raw) ?: return PropReading(YAxis.UP, "y_axis '$raw' is not up or down; y is drawn up.")
    return PropReading(yAxis)
}

private fun focusReading(raw: Any?): PropReading<LevelFocus> {
    if (raw == null || raw == ALL_LEVELS) return PropReading(LevelFocus.AllLevels)
    val level = wholeNumberOf(raw) ?: (raw as? String)?.toIntOrNull()
        ?: return PropReading(LevelFocus.AllLevels, "focus '$raw' is not all or a stack level number; every level is shown.")
    return PropReading(LevelFocus.OneLevel(level))
}

private fun showLowerReading(raw: Any?): PropReading<Boolean> = when (raw) {
    null -> PropReading(false)
    is Boolean -> PropReading(raw)
    else -> PropReading(false, "show_lower must be true or false, not '$raw'; lower levels are hidden.")
}

private fun hideTopReading(raw: Any?): PropReading<Int> {
    if (raw == null) return PropReading(0)
    val count = (wholeNumberOf(raw) ?: (raw as? String)?.toIntOrNull())?.takeIf { it >= 0 } ?: return PropReading(0, "hide_top must be a whole number of levels, not '$raw'; no level is hidden.")
    return PropReading(count)
}

private fun quarterTurnsReading(nodeId: String, raw: Any?): PropReading<Int> {
    if (raw == null) return PropReading(0)
    val turns = wholeNumberOf(raw) ?: (raw as? String)?.toIntOrNull()
        ?: return PropReading(0, "scene '$nodeId': quarter_turns must be a whole number, not '$raw'; the first aspect is drawn.")
    return PropReading(aspectOf(turns))
}

private fun finiteNumberOf(raw: Any?): Double? = ((raw as? Number)?.toDouble() ?: (raw as? String)?.toDoubleOrNull())?.takeIf { it.isFinite() }

private fun zoomReading(raw: Any?): PropReading<Double> {
    if (raw == null) return PropReading(1.0)
    val zoom = finiteNumberOf(raw)?.takeIf { it > 0 } ?: return PropReading(1.0, "zoom must be a number above 0, not '$raw'; the view is drawn at zoom 1.")
    return PropReading(clampedZoom(zoom))
}

private fun panReading(name: String, raw: Any?): PropReading<Double> {
    if (raw == null) return PropReading(0.0)
    val pan = finiteNumberOf(raw) ?: return PropReading(0.0, "$name must be a number, not '$raw'; the view is not shifted.")
    return PropReading(pan)
}

private fun highlightReading(raw: Any?): PropReading<Set<String>> {
    if (raw == null) return PropReading(emptySet())
    val entries = raw as? List<*> ?: return PropReading(emptySet(), "highlight must be a list of part ids, not '$raw'; nothing is highlighted.")
    val strays = entries.filterNot { it is String }
    val strayNote = strays.takeIf { it.isNotEmpty() }?.let { "highlight entries that are not part ids are not drawn: ${it.joinToString()}" }
    return PropReading(entries.filterIsInstance<String>().toSet(), strayNote)
}

private fun onPartTapReading(raw: Any?): PropReading<String?> = when (raw) {
    null -> PropReading(null)
    is String -> PropReading(raw)
    else -> PropReading(null, "on_part_tap must be an action name, not '$raw'; a tap dispatches nothing.")
}

private const val ONE_COLOUR = "parts are drawn in one colour."

private const val COLOR_BY = "color_by"

private fun stopReading(owner: String, index: Int, raw: Any?): PropReading<ColourStop?> {
    val fields = raw as? Map<*, *> ?: return PropReading(null, "$owner stop $index must be an object with a color, not '$raw'; it is left out.")
    val colour = colourOfHex(fields["color"]) ?: return PropReading(null, "$owner stop $index color must be #rrggbb, not '${fields["color"]}'; it is left out.")
    val rawUpTo = fields["up_to"]
    val upTo = (rawUpTo as? Number)?.toDouble()
    if (rawUpTo != null && upTo == null) return PropReading(null, "$owner stop $index up_to must be a number, not '$rawUpTo'; it is left out.")
    return PropReading(ColourStop(upTo, colour, fields["label"] as? String))
}

private fun unknownColourReading(owner: String, raw: Any?): PropReading<Long> {
    if (raw == null) return PropReading(NEUTRAL_PART_COLOUR)
    val colour = colourOfHex(raw) ?: return PropReading(NEUTRAL_PART_COLOUR, "$owner unknown_color must be #rrggbb, not '$raw'; the neutral grey is used.")
    return PropReading(colour)
}

/** [owner] is how a note names the scale: the bare prop, or the scheme it was picked from. */
private fun rampScaleReading(owner: String, channel: String, fields: Map<*, *>): PropReading<ColourScale?> {
    val ramp = when (val reading = readColourRamp("$owner ramp", fields["ramp"])) {
        is RampReading.Refused -> return PropReading(null, "${reading.notice}; $ONE_COLOUR")
        is RampReading.Readable -> reading.ramp
    }
    val scale = ColourScale(channel, emptyList(), ramp.noFigure, ramp.noFigureText, fields["format"] as? String, ramp)
    val bothNote = if ("stops" in fields) "$owner has both stops and a ramp; the ramp is used." else null
    return PropReading(scale, bothNote)
}

private fun colourScaleReading(owner: String, raw: Any?): PropReading<ColourScale?> {
    val fields = raw as? Map<*, *> ?: return PropReading(null, "$owner must be an object naming a channel and its stops, not '$raw'; $ONE_COLOUR")
    val channel = fields["channel"] as? String ?: return PropReading(null, "$owner names no channel; $ONE_COLOUR")
    if ("ramp" in fields) return rampScaleReading(owner, channel, fields)
    val rawStops = fields["stops"] as? List<*> ?: return PropReading(null, "$owner stops must be a list, not '${fields["stops"]}'; $ONE_COLOUR")
    val stops = rawStops.mapIndexed { index, stop -> stopReading(owner, index, stop) }
    val unknown = unknownColourReading(owner, fields["unknown_color"])
    val scale = ColourScale(channel, stops.mapNotNull { it.value }, unknown.value, fields["unknown_label"] as? String, fields["format"] as? String)
    val notes = (stops.mapNotNull { it.note } + listOfNotNull(unknown.note)).joinToString(" ").ifEmpty { null }
    return PropReading(scale, notes)
}

/** An unbound or absent scheme picks the first scheme in the order the spec declares them. */
private fun chosenSchemeReading(rawScheme: Any?, names: List<String>): PropReading<String?> {
    val listed = names.joinToString()
    return when {
        rawScheme == null -> PropReading(names.first())
        rawScheme !is String -> PropReading(null, "$COLOR_BY scheme must be one of the schemes $listed, not '$rawScheme'; $ONE_COLOUR")
        rawScheme !in names -> PropReading(null, "$COLOR_BY scheme '$rawScheme' is not one of the schemes $listed; $ONE_COLOUR")
        else -> PropReading(rawScheme)
    }
}

private fun schemedScaleReading(fields: Map<*, *>): PropReading<ColourScale?> {
    val schemes = fields["schemes"] as? Map<*, *> ?: return PropReading(null, "$COLOR_BY schemes must be an object of named scales, not '${fields["schemes"]}'; $ONE_COLOUR")
    if (schemes.isEmpty()) return PropReading(null, "$COLOR_BY schemes holds no scheme; $ONE_COLOUR")
    val chosen = chosenSchemeReading(fields["scheme"], schemes.keys.map { it.toString() })
    val name = chosen.value ?: return PropReading(null, chosen.note)
    return colourScaleReading("$COLOR_BY scheme '$name'", schemes[name])
}

private fun activeSchemeOf(raw: Any?): String? {
    val fields = raw as? Map<*, *> ?: return null
    val schemes = fields["schemes"] as? Map<*, *> ?: return null
    if (schemes.isEmpty()) return null
    return chosenSchemeReading(fields["scheme"], schemes.keys.map { it.toString() }).value
}

private fun colourByReading(raw: Any?): PropReading<ColourScale?> {
    if (raw == null) return PropReading(null)
    val fields = raw as? Map<*, *>
    if (fields != null && "schemes" in fields) return schemedScaleReading(fields)
    return colourScaleReading(COLOR_BY, raw)
}

/** [nodeId] names the scene in the notice for a quarter_turns it cannot read. */
fun resolveStackedSceneProps(resolved: Map<String, Any?>, nodeId: String): StackedSceneProps {
    val drawing = drawingReading(resolved["view"])
    val focus = focusReading(resolved["focus"])
    val showLower = showLowerReading(resolved["show_lower"])
    val hideTop = hideTopReading(resolved["hide_top"])
    val highlight = highlightReading(resolved["highlight"])
    val onPartTap = onPartTapReading(resolved["on_part_tap"])
    val colourScale = colourByReading(resolved[COLOR_BY])
    val yAxis = yAxisReading(resolved["y_axis"])
    val quarterTurns = quarterTurnsReading(nodeId, resolved["quarter_turns"])
    val zoom = zoomReading(resolved["zoom"])
    val panX = panReading("pan_x", resolved["pan_x"])
    val panY = panReading("pan_y", resolved["pan_y"])
    return StackedSceneProps(
        drawing = drawing.value,
        focus = focus.value,
        showLower = showLower.value,
        hideTopCount = hideTop.value,
        highlightIds = highlight.value,
        onPartTap = onPartTap.value,
        colourScale = colourScale.value,
        notes = listOfNotNull(
            drawing.note, yAxis.note, focus.note, showLower.note, hideTop.note, highlight.note, onPartTap.note, colourScale.note,
            quarterTurns.note, zoom.note, panX.note, panY.note,
        ),
        yAxis = yAxis.value,
        activeScheme = activeSchemeOf(resolved[COLOR_BY]),
        quarterTurns = quarterTurns.value,
        camera = SceneCamera(zoom.value, panX.value, panY.value),
    )
}
