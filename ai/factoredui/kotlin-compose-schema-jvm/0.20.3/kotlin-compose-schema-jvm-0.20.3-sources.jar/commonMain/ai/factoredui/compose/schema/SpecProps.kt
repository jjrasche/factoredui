package ai.factoredui.compose.schema

/**
 * Typed prop accessors for each SpecNodeType.
 *
 * The spec format stores all props as Map<String, SpecValue>. These helpers
 * extract typed values with safe defaults so the renderer doesn't need to cast.
 * Matches the prop interfaces in spec-types.ts.
 */

// --- Shared helpers ---

private fun Map<String, SpecValue>.string(key: String): String? =
    (get(key) as? SpecValue.StringValue)?.value

private fun Map<String, SpecValue>.stringOrDefault(key: String, default: String): String =
    string(key) ?: default

private fun Map<String, SpecValue>.int(key: String): Int? =
    (get(key) as? SpecValue.NumberValue)?.value?.toInt()

private fun Map<String, SpecValue>.double(key: String): Double? =
    (get(key) as? SpecValue.NumberValue)?.value

private fun Map<String, SpecValue>.boolean(key: String): Boolean? =
    (get(key) as? SpecValue.BooleanValue)?.value

// --- TextProps ---

data class TextProps(
    val value: String,
    val variant: TextVariant = TextVariant.BODY,
    val align: TextAlign = TextAlign.LEFT,
    val color: String? = null,
    val bold: Boolean = false,
    val numberOfLines: Int? = null,
)

enum class TextVariant { HEADING, SUBHEADING, BODY, CAPTION, LABEL }
enum class TextAlign { LEFT, CENTER, RIGHT }

fun Map<String, SpecValue>.asTextProps(): TextProps = TextProps(
    value = string("value") ?: "",
    variant = when (string("variant")) {
        "heading" -> TextVariant.HEADING
        "subheading" -> TextVariant.SUBHEADING
        "body" -> TextVariant.BODY
        "caption" -> TextVariant.CAPTION
        "label" -> TextVariant.LABEL
        else -> TextVariant.BODY
    },
    align = when (string("align")) {
        "center" -> TextAlign.CENTER
        "right" -> TextAlign.RIGHT
        else -> TextAlign.LEFT
    },
    color = string("color"),
    bold = boolean("bold") ?: false,
    numberOfLines = int("numberOfLines"),
)

// --- ButtonProps ---

data class ButtonProps(
    val label: String,
    val variant: ButtonVariant = ButtonVariant.PRIMARY,
    val size: ButtonSize = ButtonSize.MD,
    val icon: String? = null,
    val disabled: Boolean = false,
)

enum class ButtonVariant { PRIMARY, SECONDARY, OUTLINE, GHOST, DESTRUCTIVE }
enum class ButtonSize { SM, MD, LG }

fun Map<String, SpecValue>.asButtonProps(): ButtonProps = ButtonProps(
    label = string("label") ?: "",
    variant = when (string("variant")) {
        "secondary" -> ButtonVariant.SECONDARY
        "outline" -> ButtonVariant.OUTLINE
        "ghost" -> ButtonVariant.GHOST
        "destructive" -> ButtonVariant.DESTRUCTIVE
        else -> ButtonVariant.PRIMARY
    },
    size = when (string("size")) {
        "sm" -> ButtonSize.SM
        "lg" -> ButtonSize.LG
        else -> ButtonSize.MD
    },
    icon = string("icon"),
    disabled = boolean("disabled") ?: false,
)

// --- LayoutProps ---

data class LayoutProps(
    val gap: Int = 0,
    val padding: Int = 0,
    val align: LayoutAlign = LayoutAlign.START,
    val justify: LayoutJustify = LayoutJustify.START,
    val flex: Float = 0f,
    val background: String? = null,
)

enum class LayoutAlign { START, CENTER, END, STRETCH }
enum class LayoutJustify { START, CENTER, END, BETWEEN, AROUND }

fun Map<String, SpecValue>.asLayoutProps(): LayoutProps = LayoutProps(
    background = string("background"),
    gap = int("gap") ?: 0,
    padding = int("padding") ?: 0,
    align = when (string("align")) {
        "center" -> LayoutAlign.CENTER
        "end" -> LayoutAlign.END
        "stretch" -> LayoutAlign.STRETCH
        else -> LayoutAlign.START
    },
    justify = when (string("justify")) {
        "center" -> LayoutJustify.CENTER
        "end" -> LayoutJustify.END
        "between" -> LayoutJustify.BETWEEN
        "around" -> LayoutJustify.AROUND
        else -> LayoutJustify.START
    },
    flex = double("flex")?.toFloat() ?: 0f,
)

// --- ImageProps ---

data class ImageProps(
    val source: String,
    val alt: String = "",
    val fit: ImageFit = ImageFit.COVER,
    val aspectRatio: Float? = null,
)

enum class ImageFit { COVER, CONTAIN, FILL }

fun Map<String, SpecValue>.asImageProps(): ImageProps = ImageProps(
    source = string("source") ?: "",
    alt = string("alt") ?: "",
    fit = when (string("fit")) {
        "contain" -> ImageFit.CONTAIN
        "fill" -> ImageFit.FILL
        else -> ImageFit.COVER
    },
    aspectRatio = double("aspectRatio")?.toFloat(),
)

// --- VideoProps ---

data class VideoProps(
    val source: String,
    val autoplay: Boolean = false,
    val loop: Boolean = false,
    val position: Double? = null,
    val aspectRatio: Float? = null,
)

fun Map<String, SpecValue>.asVideoProps(): VideoProps = VideoProps(
    source = string("source") ?: "",
    autoplay = boolean("autoplay") ?: false,
    loop = boolean("loop") ?: false,
    position = double("position"),
    aspectRatio = double("aspectRatio")?.toFloat(),
)

// --- IconProps ---

data class IconProps(
    val name: String,
    val size: Int = 24,
    val color: String? = null,
)

fun Map<String, SpecValue>.asIconProps(): IconProps = IconProps(
    name = string("name") ?: "",
    size = int("size") ?: 24,
    color = string("color"),
)

// --- ListProps ---

data class ListProps(
    val data: String,
    /**
     * Live query resolved by the host's HostDataSource, e.g.
     * "query:automations:approved_at_ms IS NULL". When set (and the host wires
     * a HostDataSource into the RenderContext), the list subscribes to a Flow
     * of result sets and re-renders on every change. When null, the list reads
     * the static [data] key against the render context — behaviour is unchanged.
     * The string is opaque to the renderer; only the host's storage layer
     * interprets it.
     */
    val dataSource: String?,
    val itemTemplate: SpecNode?,
    val emptyText: String = "",
    val maxItems: Int? = null,
)

fun Map<String, SpecValue>.asListProps(): ListProps = ListProps(
    data = string("data") ?: "",
    dataSource = string("data_source"),
    itemTemplate = (get("itemTemplate") as? SpecValue.NodeValue)?.value,
    emptyText = string("emptyText") ?: "",
    maxItems = int("maxItems"),
)

// --- SpacerProps ---

data class SpacerProps(
    val size: Int = 0,
    val flex: Float = 0f,
)

fun Map<String, SpecValue>.asSpacerProps(): SpacerProps = SpacerProps(
    size = int("size") ?: 0,
    flex = double("flex")?.toFloat() ?: 0f,
)

// --- GridProps ---

/**
 * `lazy` opts into LazyVerticalGrid (windowed rendering, supports thousands of
 * items). Off by default because LazyVerticalGrid requires a bounded height —
 * dropping it inside an unbounded scrollview throws at runtime. Spec authors
 * with large item counts should set `lazy: true` and ensure the grid sits in
 * a height-bounded container (e.g. fillMaxSize, or a sized parent).
 */
data class GridProps(
    val columns: Int = 2,
    val gap: Int = 0,
    val lazy: Boolean = false,
)

fun Map<String, SpecValue>.asGridProps(): GridProps = GridProps(
    columns = int("columns") ?: 2,
    gap = int("gap") ?: 0,
    lazy = boolean("lazy") ?: false,
)

// --- ToggleProps ---

data class ToggleProps(
    val label: String = "",
)

fun Map<String, SpecValue>.asToggleProps(): ToggleProps = ToggleProps(
    label = string("label") ?: "",
)

// --- SliderProps ---

data class SliderProps(
    val min: Float = 0f,
    val max: Float = 1f,
    val step: Float? = null,
)

fun Map<String, SpecValue>.asSliderProps(): SliderProps = SliderProps(
    min = double("min")?.toFloat() ?: 0f,
    max = double("max")?.toFloat() ?: 1f,
    step = double("step")?.toFloat(),
)

// --- SelectProps ---

data class SelectOption(val label: String, val value: String)

data class SelectProps(
    val options: List<SelectOption> = emptyList(),
    val placeholder: String = "",
)

fun Map<String, SpecValue>.asSelectProps(): SelectProps {
    val rawOptions = (get("options") as? SpecValue.ArrayValue)?.value ?: emptyList()
    val parsed = rawOptions.mapNotNull { item ->
        val obj = (item as? SpecValue.ObjectValue)?.value ?: return@mapNotNull null
        val label = obj.string("label") ?: return@mapNotNull null
        val value = obj.string("value") ?: return@mapNotNull null
        SelectOption(label = label, value = value)
    }
    return SelectProps(
        options = parsed,
        placeholder = string("placeholder") ?: "",
    )
}

// --- TabsProps ---

data class TabsProps(
    val items: List<String> = emptyList(),
)

fun Map<String, SpecValue>.asTabsProps(): TabsProps {
    val raw = (get("items") as? SpecValue.ArrayValue)?.value ?: emptyList()
    return TabsProps(
        items = raw.mapNotNull { (it as? SpecValue.StringValue)?.value },
    )
}

// --- ModalProps ---

data class ModalProps(
    val title: String = "",
    val dismissible: Boolean = true,
)

fun Map<String, SpecValue>.asModalProps(): ModalProps = ModalProps(
    title = string("title") ?: "",
    dismissible = boolean("dismissible") ?: true,
)

// --- Scene3dProps ---
// Second "dense/semantic" primitive; full contract in spec-types.ts. Entities,
// camera, and lights live in the fetched world state, not in spec props.

data class Scene3dProps(
    val worldStateUrl: String,
    val worldStreamUrl: String? = null,
    val actionUrl: String? = null,
    val background: String = "neutral-gray",
    val clipUrl: String? = null,
    val clipUrlB: String? = null,
    val clipFrame: Int = 0,
    val clipFrameFraction: Float = 0f,
    val clipImpulse: Float = 0.8f,
    val clipAutoplay: Boolean = false,
    val clipSeverity: Float = 0f,
    val clipEffector: String = "R_Hand",
    val board: String? = null,
    val engineUrl: String? = null,
    val engine: String = "injury",
    val simId: String? = null,
    val bodyFrame: String? = null,
    val chrome: Boolean = true,
)

fun Map<String, SpecValue>.asScene3dProps(): Scene3dProps = Scene3dProps(
    worldStateUrl = string("world_state_url") ?: "",
    worldStreamUrl = string("world_stream_url"),
    actionUrl = string("action_url"),
    background = string("background") ?: "neutral-gray",
    clipUrl = string("clip_url"),
    clipUrlB = string("clip_url_b"),
    clipFrame = (double("frame") ?: 0.0).toInt(),
    clipFrameFraction = (double("frame") ?: 0.0).toFloat(),
    clipImpulse = (double("impulse") ?: 0.8).toFloat(),
    board = string("board"),
    engineUrl = string("engine_url"),
    engine = string("engine") ?: "injury",
    simId = string("sim_id"),
    bodyFrame = string("body_frame"),
    chrome = boolean("chrome") ?: true,
)

data class CanvasEdge(val from: String, val to: String)

data class CanvasPathPoint(val x: Float, val y: Float)

data class CanvasPath(val id: String, val color: String, val points: List<CanvasPathPoint>)

const val DEFAULT_PATH_COLOR = "#8A94AD"

const val TRAIL_MIN_ALPHA = 0.08f

fun trailSegmentAlpha(segmentIndex: Int, segmentCount: Int): Float {
    if (segmentCount <= 0) return 1f
    val headFraction = (segmentIndex + 1).toFloat() / segmentCount
    return TRAIL_MIN_ALPHA + (1f - TRAIL_MIN_ALPHA) * headFraction
}

data class CanvasViewport(val x: Float, val y: Float, val zoom: Float)

val IDENTITY_VIEWPORT = CanvasViewport(0f, 0f, 1f)

data class CanvasProps(
    val edges: List<CanvasEdge> = emptyList(),
    val nodesBinding: String? = null,
    val edgesBinding: String? = null,
    val pathsBinding: String? = null,
    val viewportBinding: String? = null,
    val onNodeArranged: String? = null,
    val onNodeTapped: String? = null,
    val onViewportChanged: String? = null,
)

fun Map<String, SpecValue>.asCanvasProps(): CanvasProps = CanvasProps(
    edges = (get("edges") as? SpecValue.ArrayValue)?.value.orEmpty().mapNotNull { edge ->
        val fields = (edge as? SpecValue.ObjectValue)?.value ?: return@mapNotNull null
        val from = fields.string("from") ?: return@mapNotNull null
        val to = fields.string("to") ?: return@mapNotNull null
        CanvasEdge(from, to)
    },
    nodesBinding = string("nodes"),
    edgesBinding = string("edges"),
    pathsBinding = string("paths"),
    viewportBinding = string("viewport"),
    onNodeArranged = string("on_node_arranged"),
    onNodeTapped = string("on_node_tap"),
    onViewportChanged = string("on_viewport_changed"),
)

// --- GeomapProps ---

data class GeoPoint(val lon: Double, val lat: Double)

enum class GeomapLayerKind { FILL, LINE }

enum class GeomapPatternKind { HATCH, CROSS, DOTS }

data class GeomapPattern(
    val kind: GeomapPatternKind,
    val color: String,
    val angle: Float = 45f,
    val spacing: Float = 8f,
    val lineWidth: Float = 2.5f,
    val background: String? = null,
)

data class GeomapFeature(
    val id: String,
    val rings: List<List<GeoPoint>>,
    val fill: String? = null,
    val stroke: String? = null,
    val strokeWidth: Float = 1f,
    val label: String? = null,
    val pattern: GeomapPattern? = null,
    val dash: List<Float>? = null,
    val geometryId: String? = null,
)

data class GeomapLegendEntry(
    val label: String,
    val fill: String? = null,
    val pattern: GeomapPattern? = null,
    val layer: String? = null,
)

data class GeomapLayer(
    val id: String,
    val kind: GeomapLayerKind,
    val features: List<GeomapFeature>,
    val visible: Boolean = true,
)

data class GeomapViewport(val lon: Double, val lat: Double, val zoom: Float)

data class GeomapProps(
    val onFeatureTap: String? = null,
    val onViewportChanged: String? = null,
)

fun Map<String, SpecValue>.asGeomapProps(): GeomapProps = GeomapProps(
    onFeatureTap = string("on_feature_tap"),
    onViewportChanged = string("on_viewport_changed"),
)

fun resolveGeomapGeometries(resolvedGeometries: Any?): Map<String, List<List<GeoPoint>>> =
    (resolvedGeometries as? Map<*, *>).orEmpty().mapNotNull { (key, rings) ->
        val id = key as? String ?: return@mapNotNull null
        val resolved = resolveGeomapRings(rings)
        if (resolved.isEmpty()) null else id to resolved
    }.toMap()

fun resolveGeomapLayers(resolvedLayers: Any?, resolvedGeometries: Any? = null): List<GeomapLayer> {
    val geometries = resolveGeomapGeometries(resolvedGeometries)
    return (resolvedLayers as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val id = fields["id"] as? String ?: return@mapNotNull null
        GeomapLayer(
            id = id,
            kind = if (fields["kind"] == "line") GeomapLayerKind.LINE else GeomapLayerKind.FILL,
            features = resolveGeomapFeatures(fields["features"], geometries),
            visible = fields["visible"] as? Boolean ?: true,
        )
    }
}

fun unresolvedGeometryRefs(resolvedLayers: Any?, resolvedGeometries: Any?): List<String> {
    val known = resolveGeomapGeometries(resolvedGeometries).keys
    return (resolvedLayers as? List<*>).orEmpty()
        .flatMap { layer -> ((layer as? Map<*, *>)?.get("features") as? List<*>).orEmpty() }
        .mapNotNull { feature -> (feature as? Map<*, *>)?.get("geometry") as? String }
        .filterNot { it in known }
        .distinct()
}

private fun resolveGeomapFeatures(
    resolvedFeatures: Any?,
    geometries: Map<String, List<List<GeoPoint>>>,
): List<GeomapFeature> =
    (resolvedFeatures as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val id = fields["id"] as? String ?: return@mapNotNull null
        val geometryId = fields["geometry"] as? String
        val rings = if (geometryId != null) geometries[geometryId].orEmpty() else resolveGeomapRings(fields["rings"])
        if (rings.isEmpty()) return@mapNotNull null
        GeomapFeature(
            id = id,
            rings = rings,
            fill = fields["fill"] as? String,
            stroke = fields["stroke"] as? String,
            strokeWidth = (fields["stroke_width"] as? Number)?.toFloat() ?: 1f,
            label = fields["label"] as? String,
            pattern = resolveGeomapPattern(fields["pattern"]),
            dash = (fields["dash"] as? List<*>)?.mapNotNull { (it as? Number)?.toFloat() }?.takeIf { it.size >= 2 },
            geometryId = geometryId,
        )
    }

fun resolveGeomapPattern(resolvedPattern: Any?): GeomapPattern? {
    val fields = resolvedPattern as? Map<*, *> ?: return null
    val color = fields["color"] as? String ?: return null
    val kind = when (fields["kind"]) {
        "cross" -> GeomapPatternKind.CROSS
        "dots" -> GeomapPatternKind.DOTS
        else -> GeomapPatternKind.HATCH
    }
    return GeomapPattern(
        kind = kind,
        color = color,
        angle = (fields["angle"] as? Number)?.toFloat() ?: 45f,
        spacing = (fields["spacing"] as? Number)?.toFloat() ?: 8f,
        lineWidth = (fields["line_width"] as? Number)?.toFloat() ?: 2.5f,
        background = fields["background"] as? String,
    )
}

fun resolveGeomapLegend(resolvedLegend: Any?): List<GeomapLegendEntry> =
    (resolvedLegend as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val label = fields["label"] as? String ?: return@mapNotNull null
        GeomapLegendEntry(
            label = label,
            fill = fields["fill"] as? String,
            pattern = resolveGeomapPattern(fields["pattern"]),
            layer = fields["layer"] as? String,
        )
    }

private fun resolveGeomapRings(resolvedRings: Any?): List<List<GeoPoint>> {
    val outer = resolvedRings as? List<*> ?: return emptyList()
    val first = outer.firstOrNull() as? List<*> ?: return emptyList()
    val isSingleRingOfPairs = first.firstOrNull() is Number
    val ringLists: List<*> = if (isSingleRingOfPairs) listOf(outer) else outer
    return ringLists.mapNotNull { ring ->
        val points = (ring as? List<*>).orEmpty().mapNotNull { point ->
            val pair = point as? List<*> ?: return@mapNotNull null
            val lon = (pair.getOrNull(0) as? Number)?.toDouble() ?: return@mapNotNull null
            val lat = (pair.getOrNull(1) as? Number)?.toDouble() ?: return@mapNotNull null
            GeoPoint(lon, lat)
        }
        if (points.size >= 3) points else null
    }
}

data class GeomapBoundsRequest(val minLon: Double, val minLat: Double, val maxLon: Double, val maxLat: Double)

fun resolveGeomapBoundsRequest(resolvedViewport: Any?): GeomapBoundsRequest? {
    val fields = resolvedViewport as? Map<*, *> ?: return null
    val corners = (fields["bounds"] as? List<*>)?.mapNotNull { (it as? Number)?.toDouble() } ?: return null
    if (corners.size != 4) return null
    return GeomapBoundsRequest(corners[0], corners[1], corners[2], corners[3])
}

fun resolveGeomapViewport(resolvedViewport: Any?): GeomapViewport? {
    val fields = resolvedViewport as? Map<*, *> ?: return null
    val lon = (fields["lon"] as? Number)?.toDouble() ?: return null
    val lat = (fields["lat"] as? Number)?.toDouble() ?: return null
    return GeomapViewport(
        lon = lon,
        lat = lat,
        zoom = (fields["zoom"] as? Number)?.toFloat() ?: 12f,
    )
}

data class FieldNodeEntry(
    val id: String,
    val x: Float,
    val y: Float,
    val glow: Float,
    val label: String,
)

fun resolveFieldNodeEntries(resolvedNodes: Any?): List<FieldNodeEntry> =
    (resolvedNodes as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val id = fields["id"] as? String ?: return@mapNotNull null
        FieldNodeEntry(
            id = id,
            x = (fields["x"] as? Number)?.toFloat() ?: 0f,
            y = (fields["y"] as? Number)?.toFloat() ?: 0f,
            glow = (fields["glow"] as? Number)?.toFloat() ?: 1f,
            label = fields["label"] as? String ?: id,
        )
    }

fun resolveCanvasEdges(resolvedEdges: Any?): List<CanvasEdge> =
    (resolvedEdges as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val from = fields["from"] as? String ?: return@mapNotNull null
        val to = fields["to"] as? String ?: return@mapNotNull null
        CanvasEdge(from, to)
    }

fun resolveCanvasPaths(resolvedPaths: Any?): List<CanvasPath> =
    (resolvedPaths as? List<*>).orEmpty().mapNotNull { entry ->
        val fields = entry as? Map<*, *> ?: return@mapNotNull null
        val id = fields["id"] as? String ?: return@mapNotNull null
        CanvasPath(
            id = id,
            color = fields["color"] as? String ?: DEFAULT_PATH_COLOR,
            points = resolveCanvasPathPoints(fields["points"]),
        )
    }

private fun resolveCanvasPathPoints(resolvedPoints: Any?): List<CanvasPathPoint> =
    (resolvedPoints as? List<*>).orEmpty().mapNotNull { point ->
        val fields = point as? Map<*, *> ?: return@mapNotNull null
        val x = (fields["x"] as? Number)?.toFloat() ?: return@mapNotNull null
        val y = (fields["y"] as? Number)?.toFloat() ?: return@mapNotNull null
        CanvasPathPoint(x, y)
    }

fun resolveCanvasViewport(resolvedViewport: Any?): CanvasViewport {
    val fields = resolvedViewport as? Map<*, *> ?: return IDENTITY_VIEWPORT
    val zoom = (fields["zoom"] as? Number)?.toFloat() ?: 1f
    return CanvasViewport(
        x = (fields["x"] as? Number)?.toFloat() ?: 0f,
        y = (fields["y"] as? Number)?.toFloat() ?: 0f,
        zoom = if (zoom > 0f) zoom else 1f,
    )
}

const val MIN_CANVAS_ZOOM = 0.2f
const val MAX_CANVAS_ZOOM = 12f

data class ViewportTransform(val translationX: Float, val translationY: Float, val scale: Float)

fun CanvasViewport.transformFor(widthPx: Float, heightPx: Float): ViewportTransform =
    ViewportTransform(translationX = -x * zoom * widthPx, translationY = -y * zoom * heightPx, scale = zoom)

fun CanvasViewport.afterTransformGesture(
    centroidXpx: Float,
    centroidYpx: Float,
    panXpx: Float,
    panYpx: Float,
    zoomDelta: Float,
    widthPx: Float,
    heightPx: Float,
): CanvasViewport {
    val newZoom = (zoom * zoomDelta).coerceIn(MIN_CANVAS_ZOOM, MAX_CANVAS_ZOOM)
    val worldX = centroidXpx / (zoom * widthPx) + x
    val worldY = centroidYpx / (zoom * heightPx) + y
    return CanvasViewport(
        x = worldX - (centroidXpx + panXpx) / (newZoom * widthPx),
        y = worldY - (centroidYpx + panYpx) / (newZoom * heightPx),
        zoom = newZoom,
    )
}
