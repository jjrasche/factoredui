package ai.factoredui.compose.renderer

import kotlin.math.round
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ai.factoredui.compose.schema.SpecNode
import ai.factoredui.compose.schema.asModalProps
import ai.factoredui.compose.schema.asSelectProps
import ai.factoredui.compose.schema.asSliderProps
import ai.factoredui.compose.schema.asTabsProps
import ai.factoredui.compose.schema.asToggleProps
import ai.factoredui.compose.schema.selectOptionKeyOf
import ai.factoredui.compose.schema.bindingPath

private const val TAB_LABEL_PADDING_DP = 16

/**
 * Form-input + selection-container primitives.
 *
 * All five share the same shape as RenderTextInput: read the raw binding path
 * from node.props for write-back, read the resolved current value from
 * resolvedProps for display, and call context.setBinding(path, value) on
 * change. node.action, when present, fires after the binding write.
 */

@Composable
internal fun RenderToggle(
    node: SpecNode,
    resolvedProps: Map<String, Any?>,
    context: RenderContext,
) {
    val props = node.props.asToggleProps()
    val writePath = node.props["value"]?.bindingPath()
    val current = (resolvedProps["value"] as? Boolean) ?: false
    val scope = rememberCoroutineScope()
    RecordDrawn { text = props.label.ifEmpty { null } }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (props.label.isNotEmpty()) {
            Text(text = props.label, color = planColour(props.color) ?: Color.Unspecified, modifier = Modifier.weight(1f))
        } else {
            Box(modifier = Modifier.weight(1f))
        }
        Switch(
            checked = current,
            onCheckedChange = { next ->
                writePath?.let { context.setBinding(it, next) }
                node.action?.let { ref -> scope.launch { context.dispatch(node.id, ref) } }
            },
            modifier = Modifier.nodeTag(node.id),
        )
    }
}

internal fun snapSliderValue(value: Float, min: Float, step: Float?): Double {
    if (step == null || step <= 0f) return value.toDouble()
    val steps = round((value - min).toDouble() / step)
    val snapped = min.toDouble() + steps * step.toString().toDouble()
    return round(snapped * SLIDER_DECIMAL_SCALE) / SLIDER_DECIMAL_SCALE
}

private const val SLIDER_DECIMAL_SCALE = 1_000_000.0

@Composable
internal fun RenderSlider(
    node: SpecNode,
    resolvedProps: Map<String, Any?>,
    context: RenderContext,
) {
    val props = node.props.asSliderProps()
    val writePath = node.props["value"]?.bindingPath()
    val current = when (val raw = resolvedProps["value"]) {
        is Number -> raw.toFloat()
        is String -> raw.toFloatOrNull() ?: props.min
        else -> props.min
    }.coerceIn(props.min, props.max)
    val scope = rememberCoroutineScope()

    val steps = props.step?.let { step ->
        if (step > 0f) (((props.max - props.min) / step).toInt() - 1).coerceAtLeast(0) else 0
    } ?: 0

    Slider(
        value = current,
        onValueChange = { next ->
            writePath?.let { context.setBinding(it, snapSliderValue(next, props.min, props.step)) }
        },
        onValueChangeFinished = {
            node.action?.let { ref -> scope.launch { context.dispatch(node.id, ref) } }
        },
        valueRange = props.min..props.max,
        steps = steps,
        modifier = Modifier
            .fillMaxWidth()
            .nodeTag(node.id),
    )
}

@Composable
internal fun RenderSelect(
    node: SpecNode,
    resolvedProps: Map<String, Any?>,
    context: RenderContext,
) {
    val props = node.props.asSelectProps()
    val writePath = node.props["value"]?.bindingPath()
    val currentKey = selectOptionKeyOf(resolvedProps["value"])
    val shownValue = if (currentKey == null) "" else resolvedProps["value"]
    val currentLabel = props.options.firstOrNull { it.key == currentKey }?.label
        ?: props.placeholder.ifEmpty { "Select…" }
    val droppedNotice = droppedOptionsNotice(node.id, props.droppedOptionIndices)
    val scope = rememberCoroutineScope()
    var expanded by remember { mutableStateOf(false) }
    RecordDrawn {
        text = currentLabel
        shownProps = mapOf("options" to props.options.map { mapOf("value" to it.value, "label" to it.label) }, "value" to shownValue)
        menu = if (expanded) props.options.map { MenuItemRecord(it.key, it.label, it.key == currentKey) } else null
        notices = listOfNotNull(droppedNotice)
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .nodeTag(node.id),
        ) {
            OutlinedButton(
                onClick = { expanded = true },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(currentLabel, maxLines = 1, overflow = TextOverflow.Ellipsis) }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
            ) {
                props.options.forEach { option ->
                    RecordMenuItemLifetime(option.key)
                    DropdownMenuItem(
                        modifier = Modifier.menuItemPlacement(option.key),
                        text = { Text(option.label) },
                        onClick = {
                            expanded = false
                            writePath?.let { context.setBinding(it, option.value) }
                            node.action?.let { ref -> scope.launch { context.dispatch(node.id, ref) } }
                        },
                    )
                }
            }
        }
        droppedNotice?.let { Text(text = it, style = MaterialTheme.typography.bodySmall, color = Color(0xFFB3261E)) }
    }
}

private fun droppedOptionsNotice(nodeId: String, droppedIndices: List<Int>): String? {
    if (droppedIndices.isEmpty()) return null
    return "select '$nodeId' dropped options ${droppedIndices.joinToString(", ")}: each needs a text 'label' and a 'value' that is text, a number or true/false"
}

@Composable
internal fun RenderTabs(
    node: SpecNode,
    resolvedProps: Map<String, Any?>,
    context: RenderContext,
) {
    val props = node.props.asTabsProps()
    val writePath = node.props["selectedIndex"]?.bindingPath()
    val rawSelected = (resolvedProps["selectedIndex"] as? Number)?.toInt() ?: 0
    val selected = rawSelected.coerceIn(0, (props.items.size - 1).coerceAtLeast(0))

    if (props.items.isEmpty()) return

    val tabs: @Composable () -> Unit = {
        props.items.forEachIndexed { index, label ->
            Tab(
                selected = index == selected,
                onClick = {
                    if (writePath != null) context.setBinding(writePath, index)
                },
                text = { Text(label, maxLines = 1, softWrap = false) },
            )
        }
    }
    val measurer = rememberTextMeasurer()
    val labelStyle = MaterialTheme.typography.titleSmall
    val density = LocalDensity.current
    Column(modifier = Modifier.nodeTag(node.id)) {
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val widestLabelPx = props.items.maxOf { measurer.measure(it, labelStyle, softWrap = false, maxLines = 1).size.width }
            val eachTabPx = constraints.maxWidth / props.items.size
            val isRoomForEveryLabel = widestLabelPx + with(density) { (2 * TAB_LABEL_PADDING_DP).dp.toPx() } <= eachTabPx
            if (isRoomForEveryLabel) TabRow(selectedTabIndex = selected, tabs = tabs)
            else ScrollableTabRow(selectedTabIndex = selected, edgePadding = 0.dp, tabs = tabs)
        }
        // Convention: one child per tab item. Mismatches render nothing.
        node.children.getOrNull(selected)?.let { child ->
            Box(modifier = Modifier.padding(top = 8.dp)) {
                RenderNode(node = child, context = context)
            }
        }
    }
}

@Composable
internal fun RenderModal(
    node: SpecNode,
    resolvedProps: Map<String, Any?>,
    context: RenderContext,
) {
    val props = node.props.asModalProps()
    val title = (resolvedProps["title"] as? String) ?: props.title
    val scope = rememberCoroutineScope()

    val onDismiss: () -> Unit = {
        node.action?.let { ref -> scope.launch { context.dispatch(node.id, ref) } }
    }

    AlertDialog(
        onDismissRequest = if (props.dismissible) onDismiss else ({}),
        title = if (title.isNotEmpty()) ({ Text(title) }) else null,
        text = {
            Column { node.children.forEach { child -> RenderNode(node = child, context = context) } }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                enabled = props.dismissible,
            ) { Text("Close") }
        },
        modifier = Modifier.nodeTag(node.id),
    )
}
