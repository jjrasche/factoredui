package ai.factoredui.compose.renderer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.alpha
import ai.factoredui.compose.schema.bindingPath
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import ai.factoredui.compose.schema.GeomapLegendEntry
import ai.factoredui.compose.schema.GeomapPattern
import ai.factoredui.compose.schema.resolveGeomapLegend
import ai.factoredui.compose.schema.GeoPoint
import ai.factoredui.compose.schema.GeomapBoundsRequest
import ai.factoredui.compose.schema.resolveGeomapBoundsRequest
import ai.factoredui.compose.schema.unresolvedGeometryRefs
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import ai.factoredui.compose.scene3d.drawTriangleBatch
import ai.factoredui.compose.schema.ActionRef
import ai.factoredui.compose.schema.GeomapFeature
import ai.factoredui.compose.schema.GeomapLayer
import ai.factoredui.compose.schema.GeomapLayerKind
import ai.factoredui.compose.score.ScoreShade
import ai.factoredui.compose.score.ScoreShadeReading
import ai.factoredui.compose.score.ShadeScale
import ai.factoredui.compose.score.ShadedColour
import ai.factoredui.compose.score.scoreBoundsOf
import ai.factoredui.compose.score.readScoreShade
import ai.factoredui.compose.score.shadeFor
import ai.factoredui.compose.schema.GeomapViewport
import ai.factoredui.compose.schema.SpecNode
import ai.factoredui.compose.schema.SpecValue
import ai.factoredui.compose.schema.asGeomapProps
import ai.factoredui.compose.schema.geomapRasterProblems
import ai.factoredui.compose.schema.resolveGeomapLayers
import ai.factoredui.compose.schema.resolveGeomapRasterLayers
import ai.factoredui.compose.schema.resolveGeomapViewport
import ai.factoredui.compose.schema.resolveGeomapSelection
import ai.factoredui.compose.schema.DEFAULT_POINT_RADIUS
import kotlinx.coroutines.launch
import kotlin.math.abs

private const val DEFAULT_STROKE_ARGB = 0xFF2C3E50.toInt()
private const val LABEL_FIT = 0.9f
private val LABEL_FONT_SIZE = 12.sp

internal class TessellatedFeature(
    val featureId: String,
    val fillArgb: Int?,
    val strokeArgb: Int?,
    val strokeWidth: Float,
    val worldRings: List<DoubleArray>,
    val triangleWorld: DoubleArray,
    val bounds: WorldBounds?,
    val pattern: GeomapPattern?,
    val label: String?,
    val dash: List<Float>?,
    val labelCandidates: List<GeomapLabelAnchor>,
    val radius: Float = DEFAULT_POINT_RADIUS,
    val values: Map<String, Double?> = emptyMap(),
    val info: Map<String, Any> = emptyMap(),
    val figures: Map<String, Double?> = emptyMap(),
)

/** The fill a feature draws with now: its own, or the colour its values earn under the node's `shade_by`; null when it has none or the shade hides it. */
internal fun featureFillArgb(feature: TessellatedFeature, shade: ScoreShade?, dimArgb: Int): Int? {
    if (shade == null || !shade.hasScoreInput(feature.values, feature.figures)) return feature.fillArgb
    return when (val shaded = shadeFor(shade, feature.values, feature.figures)) {
        is ShadedColour.Coloured -> shaded.colour.toInt()
        ShadedColour.Dimmed -> dimArgb
        ShadedColour.Hidden -> null
    }
}

internal fun shadeWithRanks(shade: ScoreShade, tessellation: GeomapTessellation): ScoreShade {
    val features = tessellation.layers.flatMap { layer -> layer.features }
    val loaded = if (shade.isRaw) shade.withExtentsOf(features.map { it.figures }) else shade
    if (loaded.scale != ShadeScale.RANK) return loaded
    return loaded.withRanksOf(features.mapNotNull { feature -> scoreBoundsOf(loaded, feature.values, feature.figures)?.middle })
}

/** Under the minimum, dimmed or hidden: it takes no outline, label or tap, and is not in the list. */
internal fun isShadedOut(feature: TessellatedFeature, shade: ScoreShade?): Boolean =
    shade != null && shade.hasScoreInput(feature.values, feature.figures) &&
        shadeFor(shade, feature.values, feature.figures) !is ShadedColour.Coloured

/** The features a selection outlines: the first drawn feature of each selected id, so an id that two layers repeat is outlined once. */
internal fun featuresToOutline(
    tessellation: GeomapTessellation,
    selection: Set<String>,
    zoom: Float,
    view: WorldBounds,
    shade: ScoreShade?,
): List<TessellatedFeature> {
    if (selection.isEmpty()) return emptyList()
    val outlined = LinkedHashMap<String, TessellatedFeature>()
    for (layer in tessellation.layers) {
        if (!layer.isShownAt(zoom) || layer.kind == GeomapLayerKind.POINT) continue
        for (feature in layer.featuresIn(view)) {
            if (feature.featureId !in selection || feature.featureId in outlined || isShadedOut(feature, shade)) continue
            outlined[feature.featureId] = feature
        }
    }
    return outlined.values.toList()
}

private const val MIN_SEPARATION_FROM_GROUND = 40.0

private fun distanceBetween(first: androidx.compose.ui.graphics.Color, second: androidx.compose.ui.graphics.Color): Double {
    val red = (first.red - second.red) * 255.0
    val green = (first.green - second.green) * 255.0
    val blue = (first.blue - second.blue) * 255.0
    return kotlin.math.sqrt(red * red + green * green + blue * blue)
}

/** Every ramp colour (stops, the over colour, no_figure) that sits nearly on the theme's background, where a parcel in it would vanish. */
internal fun shadePaletteProblems(shade: ScoreShade, theme: SpecTheme): List<String> {
    val named = shade.ramp.stops.map { colourHex(it.colour) to it.colour } +
        ("over" to shade.ramp.over) + ("no_figure" to shade.ramp.noFigure)
    return named.mapNotNull { (name, argb) ->
        val colour = androidx.compose.ui.graphics.Color(argb.toInt())
        val gap = distanceBetween(colour, theme.ground)
        if (gap < MIN_SEPARATION_FROM_GROUND) "shade_by ramp colour $name is nearly the background (${gap.toInt()} apart)" else null
    }
}

private fun colourHex(argb: Long): String = "#" + (argb and 0xFFFFFF).toString(16).padStart(6, '0')

internal var geomapTessellationRuns = 0

internal class TessellatedLayer(
    val layerId: String,
    val kind: GeomapLayerKind,
    val visible: Boolean,
    val features: List<TessellatedFeature>,
    val minZoom: Float? = null,
    val maxZoom: Float? = null,
)

// The style-spec convention: hidden below min_zoom, and already hidden AT max_zoom.
internal fun TessellatedLayer.isShownAt(zoom: Float): Boolean =
    visible && (minZoom == null || zoom >= minZoom) && (maxZoom == null || zoom < maxZoom)

internal class GeomapTessellation(
    val layers: List<TessellatedLayer>,
    val worldBounds: WorldBounds?,
)

internal data class GeomapHit(val layerId: String, val featureId: String)

@Composable
internal fun RenderGeomap(node: SpecNode, resolvedProps: Map<String, Any?>, context: RenderContext) {
    val props = node.props.asGeomapProps()
    val layersData = resolvedProps["layers"]
    val geometriesData = resolvedProps["geometries"]
    val tessellation = remember(layersData, geometriesData) {
        tessellateGeomapLayers(resolveGeomapLayers(layersData, geometriesData))
    }
    val missingGeometries = remember(layersData, geometriesData) { unresolvedGeometryRefs(layersData, geometriesData) }
    val shadeData = resolvedProps["shade_by"]
    val shadeReading = remember(shadeData) { shadeData?.let { readScoreShade("shade_by", it) } }
    val readShade = (shadeReading as? ScoreShadeReading.Readable)?.shade
    val shade = remember(readShade, tessellation) { readShade?.let { shadeWithRanks(it, tessellation) } }
    val theme = LocalSpecTheme.current
    val dimArgb = theme.dimmed.toArgb()
    val shadeNotice = (shadeReading as? ScoreShadeReading.Refused)?.notice
        ?: readShade?.let { shadePaletteProblems(it, theme).firstOrNull() }
    val hostCentreViewport = resolveGeomapViewport(resolvedProps["viewport"])
    val hostBounds = resolveGeomapBoundsRequest(resolvedProps["viewport"])
    val legend = resolveGeomapLegend(resolvedProps["legend"])
    val rasterLayers = remember(layersData) { resolveGeomapRasterLayers(layersData) }
    val rasterProblems = remember(layersData) { geomapRasterProblems(layersData) }
    val rasterFailures = remember { RasterFailures() }
    val visibilityPath = node.props["layer_visibility"]?.bindingPath()
    val boundVisibility = (resolvedProps["layer_visibility"] as? Map<*, *>)
        ?.mapNotNull { (key, value) -> (key as? String)?.let { id -> (value as? Boolean)?.let { id to it } } }
        ?.toMap().orEmpty()
    var localVisibility by remember { mutableStateOf(emptyMap<String, Boolean>()) }
    val layerVisibility = if (visibilityPath != null) boundVisibility else localVisibility
    val shownTessellation = remember(tessellation, layerVisibility) { tessellation.withVisibility(layerVisibility) }
    val selectedPath = node.props["selected"]?.bindingPath()
    var localSelection by remember { mutableStateOf(resolveGeomapSelection(resolvedProps["selected"])) }
    val selection = if (selectedPath != null) resolveGeomapSelection(resolvedProps["selected"]) else localSelection
    val selectionStyle = GeomapSelectionStyle(
        strokeArgb = parseGeomapColor(resolvedProps["selection_stroke"] as? String) ?: LocalSpecTheme.current.ink.toArgb(),
        strokeWidth = (resolvedProps["selection_stroke_width"] as? Number)?.toFloat() ?: DEFAULT_SELECTION_STROKE_WIDTH,
    )
    val shadeOutPath = node.props["shade_out"]?.bindingPath()
    val shadeTop = shadeOutTopCount(resolvedProps["shade_top"])
    val topRows = remember(shade, tessellation, shadeTop, shadeOutPath) {
        if (shade != null && shadeOutPath != null) shadeOutTop(shade, tessellation, shadeTop) else null
    }
    val selectedOut = remember(shade, tessellation, selection, shadeOutPath) {
        if (shade != null && shadeOutPath != null) shadeOutSelected(shade, tessellation, selection) else null
    }
    val unmeasuredText = remember(shade, tessellation, shadeOutPath) {
        if (shade != null && shadeOutPath != null) shadeOutUnmeasuredText(shade, tessellation) else null
    }
    LaunchedEffect(topRows) { if (topRows != null && shadeOutPath != null) context.setBinding("$shadeOutPath.top", topRows) }
    LaunchedEffect(unmeasuredText) { if (unmeasuredText != null && shadeOutPath != null) context.setBinding("$shadeOutPath.unmeasured_text", unmeasuredText) }
    LaunchedEffect(selectedOut, shadeOutPath) { if (shadeOutPath != null && shade != null) context.setBinding("$shadeOutPath.selected", selectedOut) }
    val screenDensity = androidx.compose.ui.platform.LocalDensity.current.density
    val scope = rememberCoroutineScope()
    val labelMeasurer = rememberTextMeasurer()
    val labelInk = LocalSpecTheme.current.ink
    val labelHalo = LocalSpecTheme.current.ground
    BoxWithConstraints(modifier = Modifier.fillMaxSize().nodeTag(node.id).clipToBounds()) {
        val widthPx = constraints.maxWidth.toFloat()
        val heightPx = constraints.maxHeight.toFloat()
        // Only the renderer knows its pixel size, so a host asking to frame a region hands over
        // bounds and the fit is done here rather than guessed from outside.
        val hostViewport = hostCentreViewport ?: hostBounds?.let { request ->
            fitGeomapViewport(
                worldBoundsOfRequest(request), widthPx, heightPx,
                margin = request.margin ?: FIT_MARGIN,
                insetBottomPx = (request.insetBottomDp * screenDensity).toFloat(),
            )
        }
        var viewport by remember(widthPx, heightPx) {
            mutableStateOf(hostViewport ?: fitGeomapViewport(tessellation.worldBounds, widthPx, heightPx))
        }
        LaunchedEffect(hostViewport) { hostViewport?.let { viewport = it } }
        GeomapRasterTiles(rasterLayers, layerVisibility, viewport, widthPx, heightPx, context.tileLoader, theme.dimmed, rasterFailures)
        Canvas(
            modifier = Modifier.fillMaxSize()
                .pointerInput(shownTessellation, props.onFeatureTap, selection, selectedPath, shade) {
                    val onFeatureTap = props.onFeatureTap
                    detectTapGestures(onTap = { offset ->
                        val hit = hitTestGeomap(shownTessellation, viewport, widthPx, heightPx, offset.x, offset.y, density, shade)
                        val nextSelection = selectionAfterTap(selection, hit)
                        if (selectedPath != null) context.setBinding(selectedPath, nextSelection)
                        else localSelection = nextSelection.toSet()
                        if (hit != null && onFeatureTap != null) {
                            scope.launch { context.dispatch(node.id, featureTapAction(onFeatureTap, hit)) }
                        }
                    })
                }
                .pointerInput(widthPx, heightPx) {
                    detectTransformGestures { centroid, pan, zoomDelta, _ ->
                        viewport = viewport.afterGeomapGesture(
                            centroid.x, centroid.y, pan.x, pan.y, zoomDelta, widthPx, heightPx,
                        )
                    }
                }
                .pointerInput(props.onViewportChanged) {
                    val onViewportChanged = props.onViewportChanged
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        do {
                            val event = awaitPointerEvent()
                        } while (event.changes.any { it.pressed })
                        if (onViewportChanged != null) {
                            scope.launch { context.dispatch(node.id, viewportChangedAction(onViewportChanged, viewport)) }
                        }
                    }
                },
        ) {
            drawGeomapTessellation(shownTessellation, viewport, widthPx, heightPx, labelMeasurer, labelInk, labelHalo, selection, selectionStyle, shade, dimArgb)
        }
        GeomapRasterNotes(node.id, rasterLayers, layerVisibility, viewport.zoom, rasterProblems, rasterFailures)
        if (shadeNotice != null) {
            Text(
                text = shadeNotice,
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
                style = MaterialTheme.typography.bodySmall,
                color = LocalSpecTheme.current.ink,
            )
        }
        if (legend.isNotEmpty()) {
            GeomapLegend(
                entries = legend,
                nodeId = node.id,
                isLayerShown = { layerId -> layerVisibility[layerId] ?: true },
                onToggleLayer = { layerId ->
                    val shown = layerVisibility[layerId] ?: true
                    if (visibilityPath != null) context.setBinding("$visibilityPath.$layerId", !shown)
                    else localVisibility = localVisibility + (layerId to !shown)
                },
                modifier = Modifier.align(Alignment.BottomStart),
            )
        }
        if (missingGeometries.isNotEmpty()) {
            Text(
                text = "${missingGeometries.size} geometry reference(s) have no entry in `geometries`: " +
                    missingGeometries.joinToString(", "),
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
                style = MaterialTheme.typography.bodySmall,
                color = LocalSpecTheme.current.ink,
            )
        }
    }
}

// A geometry referenced by several layers is projected and triangulated ONCE and shared by
// reference — the point of the table, since four views of 83 counties are one set of outlines.
private class SharedGeometry(val worldRings: List<DoubleArray>, val bounds: WorldBounds?) {
    var triangles: DoubleArray? = null
}

internal fun tessellateGeomapLayers(layers: List<GeomapLayer>): GeomapTessellation {
    geomapTessellationRuns++
    var bounds: WorldBounds? = null
    val shared = mutableMapOf<String, SharedGeometry>()
    val tessellatedLayers = layers.map { layer ->
        val fillsAsPaths = isFilledAsPaths(layer)
        val features = layer.features.map { feature ->
            val geometry = feature.geometryId?.let { id ->
                shared.getOrPut(id) { SharedGeometry(projectRings(feature.rings), worldBoundsOf(feature.rings)) }
            }
            val featureBounds = geometry?.bounds ?: worldBoundsOf(feature.rings)
            featureBounds?.let { bounds = bounds?.union(it) ?: it }
            tessellateFeature(feature, layer.kind, featureBounds, geometry, fillsAsPaths)
        }
        TessellatedLayer(layer.id, layer.kind, layer.visible, features, layer.minZoom, layer.maxZoom)
    }
    return GeomapTessellation(tessellatedLayers, bounds)
}

private const val PATH_FILL_POINTS_PER_FEATURE = 24

// A layer of big outlines (counties) is cheaper filled as one path each than as a triangle batch whose
// vertices are rebuilt every frame; a layer of many small shapes (parcels) is the other way round.
internal fun isFilledAsPaths(layer: GeomapLayer): Boolean {
    if (layer.kind != GeomapLayerKind.FILL || layer.features.isEmpty()) return false
    val points = layer.features.sumOf { feature -> feature.rings.sumOf { it.size } }
    return points / layer.features.size >= PATH_FILL_POINTS_PER_FEATURE
}

private fun projectRings(rings: List<List<GeoPoint>>): List<DoubleArray> = rings.map { ring ->
    DoubleArray(ring.size * 2).also { flat ->
        ring.forEachIndexed { index, point ->
            flat[index * 2] = lonToWorldX(point.lon)
            flat[index * 2 + 1] = latToWorldY(point.lat)
        }
    }
}

private fun tessellateFeature(
    feature: GeomapFeature,
    kind: GeomapLayerKind,
    bounds: WorldBounds?,
    shared: SharedGeometry?,
    fillsAsPaths: Boolean,
): TessellatedFeature {
    val worldRings = shared?.worldRings ?: projectRings(feature.rings)
    val fillArgb = when (kind) {
        GeomapLayerKind.FILL -> parseGeomapColor(feature.fill)
        GeomapLayerKind.POINT -> parseGeomapColor(feature.fill) ?: DEFAULT_STROKE_ARGB
        GeomapLayerKind.LINE -> null
    }
    val needsTriangles = kind == GeomapLayerKind.FILL && (fillArgb != null || feature.values.isNotEmpty() || feature.figures.isNotEmpty()) && worldRings.size == 1 && !fillsAsPaths
    val triangleWorld = when {
        !needsTriangles -> DoubleArray(0)
        shared != null -> shared.triangles ?: expandTriangles(worldRings).also { shared.triangles = it }
        else -> expandTriangles(worldRings)
    }
    return TessellatedFeature(
        featureId = feature.id,
        fillArgb = fillArgb,
        strokeArgb = parseGeomapColor(feature.stroke)
            ?: if (kind == GeomapLayerKind.LINE) parseGeomapColor(feature.fill) ?: DEFAULT_STROKE_ARGB else null,
        strokeWidth = feature.strokeWidth,
        worldRings = worldRings,
        triangleWorld = triangleWorld,
        bounds = bounds,
        pattern = if (kind == GeomapLayerKind.FILL) feature.pattern else null,
        label = feature.label?.takeIf { it.isNotBlank() },
        dash = feature.dash,
        labelCandidates = if (feature.label.isNullOrBlank() || kind != GeomapLayerKind.FILL) emptyList() else geomapLabelCandidatesOf(worldRings),
        radius = feature.radius,
        values = feature.values,
        info = feature.info,
        figures = feature.figures,
    )
}

// Drawing every feature every frame is what made a county of parcels unusable; a feature
// whose bounds miss the view contributes no pixels, so it is skipped before any vertex work.
private fun TessellatedLayer.featuresIn(view: WorldBounds): List<TessellatedFeature> =
    features.filter { feature -> feature.bounds?.intersects(view) ?: false }

// A point's bounds are a single position but its disc has a pixel radius, so the view is
// widened by that radius or a well just off-screen would vanish while its edge still shows.
private fun TessellatedLayer.pointsIn(view: WorldBounds, scale: Double, density: Float): List<TessellatedFeature> =
    features.filter { feature -> feature.bounds?.intersects(view.inflatedBy(feature.radius * density / scale)) ?: false }

private fun isTapOnPoint(feature: TessellatedFeature, worldX: Double, worldY: Double, reachWorld: Double): Boolean {
    val deltaX = worldX - feature.worldRings[0][0]
    val deltaY = worldY - feature.worldRings[0][1]
    return deltaX * deltaX + deltaY * deltaY <= reachWorld * reachWorld
}

private const val POINT_TAP_SLOP = 4f
private const val POINT_LABEL_GAP = 4f

internal fun GeomapTessellation.withVisibility(overrides: Map<String, Boolean>): GeomapTessellation =
    if (overrides.isEmpty()) this
    else GeomapTessellation(
        layers.map { layer ->
            TessellatedLayer(
                layer.layerId, layer.kind, layer.visible && (overrides[layer.layerId] ?: true), layer.features, layer.minZoom, layer.maxZoom,
            )
        },
        worldBounds,
    )

internal fun drawnGeomapFeatureIds(
    tessellation: GeomapTessellation,
    viewport: GeomapViewport,
    widthPx: Float,
    heightPx: Float,
): List<String> {
    val view = visibleWorldBounds(viewport, widthPx, heightPx)
    return tessellation.layers.filter { it.isShownAt(viewport.zoom) }.flatMap { layer -> layer.featuresIn(view).map { it.featureId } }
}

private fun expandTriangles(worldRings: List<DoubleArray>): DoubleArray {
    val triangulated = worldRings.map { ring -> ring to earClipTriangulate(ring) }
    val expanded = DoubleArray(triangulated.sumOf { it.second.size } * 2)
    var written = 0
    for ((ring, indices) in triangulated) {
        for (vertexIndex in indices) {
            expanded[written++] = ring[vertexIndex * 2]
            expanded[written++] = ring[vertexIndex * 2 + 1]
        }
    }
    return expanded
}

internal fun hitTestGeomap(
    tessellation: GeomapTessellation,
    viewport: GeomapViewport,
    widthPx: Float,
    heightPx: Float,
    tapXpx: Float,
    tapYpx: Float,
    density: Float = 1f,
    shade: ScoreShade? = null,
): GeomapHit? {
    val scale = geomapScalePx(viewport.zoom)
    val worldX = lonToWorldX(viewport.lon) + (tapXpx - widthPx / 2.0) / scale
    val worldY = latToWorldY(viewport.lat) + (tapYpx - heightPx / 2.0) / scale
    for (layer in tessellation.layers.asReversed()) {
        if (!layer.isShownAt(viewport.zoom)) continue
        for (feature in layer.features.asReversed()) {
            if (isShadedOut(feature, shade)) continue
            val isHit = if (layer.kind == GeomapLayerKind.POINT) {
                isTapOnPoint(feature, worldX, worldY, (feature.radius + POINT_TAP_SLOP) * density / scale)
            } else {
                isPointInRings(worldX, worldY, feature.worldRings)
            }
            if (isHit) {
                return GeomapHit(layer.layerId, feature.featureId)
            }
        }
    }
    return null
}

private fun DrawScope.drawGeomapTessellation(
    tessellation: GeomapTessellation,
    viewport: GeomapViewport,
    widthPx: Float,
    heightPx: Float,
    labelMeasurer: TextMeasurer,
    labelInk: Color,
    labelHalo: Color,
    selection: Set<String>,
    selectionStyle: GeomapSelectionStyle,
    shade: ScoreShade?,
    dimArgb: Int,
) {
    val scale = geomapScalePx(viewport.zoom)
    val centerX = lonToWorldX(viewport.lon)
    val centerY = latToWorldY(viewport.lat)
    fun screenX(worldX: Double): Float = ((worldX - centerX) * scale + widthPx / 2.0).toFloat()
    fun screenY(worldY: Double): Float = ((worldY - centerY) * scale + heightPx / 2.0).toFloat()
    val view = visibleWorldBounds(viewport, widthPx, heightPx)

    for (layer in tessellation.layers) {
        if (!layer.isShownAt(viewport.zoom) || layer.kind != GeomapLayerKind.FILL) continue
        val inView = layer.featuresIn(view)
        var vertexCount = 0
        for (feature in inView) vertexCount += feature.triangleWorld.size / 2
        if (vertexCount >= 3) {
            val positions = FloatArray(vertexCount * 2)
            val colors = IntArray(vertexCount)
            var vertex = 0
            for (feature in inView) {
                val fill = featureFillArgb(feature, shade, dimArgb) ?: continue
                val triangles = feature.triangleWorld
                for (index in 0 until triangles.size / 2) {
                    positions[vertex * 2] = screenX(triangles[index * 2])
                    positions[vertex * 2 + 1] = screenY(triangles[index * 2 + 1])
                    colors[vertex] = fill
                    vertex++
                }
            }
            drawIntoCanvas { canvas -> drawTriangleBatch(canvas, positions, colors, vertex) }
        }
        // Inner rings are holes, which even-odd fills as empty and the triangle batch cannot express; a layer filled as paths has no triangles at all.
        for (feature in inView) {
            val fill = featureFillArgb(feature, shade, dimArgb) ?: continue
            if (feature.triangleWorld.isNotEmpty()) continue
            drawPath(screenPathOf(feature.worldRings, closed = true, ::screenX, ::screenY), Color(fill))
        }
    }

    for (layer in tessellation.layers) {
        if (!layer.isShownAt(viewport.zoom)) continue
        for (feature in layer.featuresIn(view)) {
            if (isShadedOut(feature, shade)) continue
            val pattern = feature.pattern ?: shade?.let { unsettledMarkFor(it, feature.values, feature.figures, colourHex(labelInk.toArgb().toLong())) } ?: continue
            paintGeomapPattern(screenPathOf(feature.worldRings, closed = true, ::screenX, ::screenY), pattern)
        }
    }

    for (layer in tessellation.layers) {
        if (!layer.isShownAt(viewport.zoom) || layer.kind == GeomapLayerKind.POINT) continue
        for (feature in layer.featuresIn(view)) {
            if (isShadedOut(feature, shade)) continue
            val strokeArgb = feature.strokeArgb ?: continue
            val path = Path()
            for (ring in feature.worldRings) {
                if (ring.size / 2 < 2) continue
                path.addScreenRing(ring, ::screenX, ::screenY)
                if (layer.kind == GeomapLayerKind.FILL) path.close()
            }
            val dashEffect = feature.dash?.let { intervals ->
                PathEffect.dashPathEffect(intervals.map { it * density }.toFloatArray())
            }
            drawPath(path, color = Color(strokeArgb), style = Stroke(width = feature.strokeWidth * density, pathEffect = dashEffect))
        }
    }

    for (layer in tessellation.layers) {
        if (!layer.isShownAt(viewport.zoom) || layer.kind != GeomapLayerKind.POINT) continue
        for (feature in layer.pointsIn(view, scale, density)) {
            val centre = Offset(screenX(feature.worldRings[0][0]), screenY(feature.worldRings[0][1]))
            if (isShadedOut(feature, shade)) continue
            featureFillArgb(feature, shade, dimArgb)?.let { drawCircle(Color(it), radius = feature.radius * density, center = centre) }
            feature.strokeArgb?.let {
                drawCircle(Color(it), radius = feature.radius * density, center = centre, style = Stroke(width = feature.strokeWidth * density))
            }
        }
    }

    if (selection.isNotEmpty()) {
        for (layer in tessellation.layers) {
            if (!layer.isShownAt(viewport.zoom)) continue
            if (layer.kind == GeomapLayerKind.POINT) {
                for (feature in layer.pointsIn(view, scale, density)) {
                    if (feature.featureId !in selection) continue
                    drawCircle(
                        Color(selectionStyle.strokeArgb),
                        radius = (feature.radius + selectionStyle.strokeWidth) * density,
                        center = Offset(screenX(feature.worldRings[0][0]), screenY(feature.worldRings[0][1])),
                        style = Stroke(width = selectionStyle.strokeWidth * density),
                    )
                }
                continue
            }
        }
        for (feature in featuresToOutline(tessellation, selection, viewport.zoom, view, shade)) {
            val kind = tessellation.layers.first { feature in it.features }.kind
            drawPath(
                screenPathOf(feature.worldRings, closed = kind == GeomapLayerKind.FILL, ::screenX, ::screenY),
                color = Color(selectionStyle.strokeArgb),
                style = Stroke(width = selectionStyle.strokeWidth * density),
            )
        }
    }

    // Labels never overprint: the upper layer, and the later feature within a layer, claims its
    // box first — the same order a tap resolves in.
    val claimedBoxes = mutableListOf<Rect>()
    for (layer in tessellation.layers.asReversed()) {
        if (!layer.isShownAt(viewport.zoom)) continue
        val candidates = if (layer.kind == GeomapLayerKind.POINT) layer.pointsIn(view, scale, density) else layer.featuresIn(view)
        for (feature in candidates.asReversed()) {
            if (isShadedOut(feature, shade)) continue
            val label = feature.label ?: continue
            val measured = labelMeasurer.measure(label, TextStyle(color = labelInk, fontSize = LABEL_FONT_SIZE))
            val labelSize = Size(measured.size.width.toFloat(), measured.size.height.toFloat())
            val candidateCorners = if (layer.kind == GeomapLayerKind.POINT) {
                val centreX = screenX(feature.worldRings[0][0])
                val top = screenY(feature.worldRings[0][1]) - labelSize.height / 2f
                val gap = (feature.radius + POINT_LABEL_GAP) * density
                listOf(Offset(centreX + gap, top), Offset(centreX - gap - labelSize.width, top))
            } else {
                // The whole label box must sit on the county's own land, which is also what keeps eleven
                // thousand parcel names off a county-scale view without a separate zoom threshold.
                val anchor = placeGeomapLabel(
                    feature.labelCandidates,
                    feature.worldRings,
                    halfWidthWorld = measured.size.width / 2.0 / scale / LABEL_FIT,
                    halfHeightWorld = measured.size.height / 2.0 / scale / LABEL_FIT,
                ) ?: continue
                listOf(Offset(screenX(anchor.x) - labelSize.width / 2f, screenY(anchor.y) - labelSize.height / 2f))
            }
            val box = candidateCorners.map { Rect(it, labelSize) }.firstOrNull { candidate ->
                candidate.isWithin(widthPx, heightPx) && claimedBoxes.none { it.overlaps(candidate) }
            } ?: continue
            claimedBoxes += box
            drawText(measured, color = labelHalo, topLeft = box.topLeft, drawStyle = Stroke(width = LABEL_HALO_WIDTH * density, join = StrokeJoin.Round))
            drawText(measured, topLeft = box.topLeft)
        }
    }
}

private fun Rect.isWithin(widthPx: Float, heightPx: Float): Boolean =
    left >= 0f && top >= 0f && right <= widthPx && bottom <= heightPx

private const val LABEL_HALO_WIDTH = 3f

private fun worldBoundsOfRequest(request: GeomapBoundsRequest): WorldBounds? = worldBoundsOf(
    listOf(listOf(GeoPoint(request.minLon, request.minLat), GeoPoint(request.maxLon, request.maxLat))),
)

private fun screenPathOf(
    worldRings: List<DoubleArray>,
    closed: Boolean,
    screenX: (Double) -> Float,
    screenY: (Double) -> Float,
): Path {
    val path = Path().apply { fillType = PathFillType.EvenOdd }
    for (ring in worldRings) {
        if (ring.size / 2 < 2) continue
        path.addScreenRing(ring, screenX, screenY)
        if (closed) path.close()
    }
    return path
}

private const val MIN_SCREEN_STEP_PX = 0.5f

// A point less than half a pixel from the one before it adds nothing the eye can see, and a county
// outline has several times more of them than pixels; the last point is always kept so the ring closes true.
private fun Path.addScreenRing(ring: DoubleArray, screenX: (Double) -> Float, screenY: (Double) -> Float) {
    val pointCount = ring.size / 2
    var lastX = screenX(ring[0])
    var lastY = screenY(ring[1])
    moveTo(lastX, lastY)
    for (index in 1 until pointCount) {
        val x = screenX(ring[index * 2])
        val y = screenY(ring[index * 2 + 1])
        if (index < pointCount - 1 && abs(x - lastX) + abs(y - lastY) < MIN_SCREEN_STEP_PX) continue
        lineTo(x, y)
        lastX = x
        lastY = y
    }
}

@Composable
private fun GeomapLegend(
    entries: List<GeomapLegendEntry>,
    nodeId: String,
    isLayerShown: (String) -> Boolean,
    onToggleLayer: (String) -> Unit,
    modifier: Modifier,
) {
    Column(
        modifier = modifier.padding(8.dp).background(LocalSpecTheme.current.ground.copy(alpha = 0.9f)).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        entries.forEachIndexed { index, entry ->
            // An entry that names a layer is its switch; one that names none — a class within a
            // single choropleth — is a key only, and tapping it does nothing.
            val layerId = entry.layer
            val shown = layerId == null || isLayerShown(layerId)
            val rowModifier = Modifier.nodeTag("$nodeId:legend:${layerId ?: index}")
                .let { base ->
                    if (layerId == null) base
                    else base.clickable(interactionSource = null, indication = null) { onToggleLayer(layerId) }
                }
                .alpha(if (shown) 1f else 0.35f)
            Row(modifier = rowModifier, verticalAlignment = Alignment.CenterVertically) {
                Canvas(modifier = Modifier.size(width = 28.dp, height = 18.dp)) {
                    val swatch = Path().apply { addRect(Rect(Offset.Zero, size)) }
                    entry.fill?.let(::parseGeomapColor)?.let { drawPath(swatch, Color(it)) }
                    entry.pattern?.let { paintGeomapPattern(swatch, it) }
                }
                Text(
                    text = entry.label,
                    modifier = Modifier.padding(start = 6.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalSpecTheme.current.ink,
                )
            }
        }
    }
}

private class GeomapSelectionStyle(val strokeArgb: Int, val strokeWidth: Float)

private const val DEFAULT_SELECTION_STROKE_WIDTH = 3f

internal fun selectionAfterTap(selection: Set<String>, hit: GeomapHit?): List<String> =
    ai.factoredui.compose.schema.selectionAfterTap(selection, hit?.featureId)

private fun featureTapAction(action: String, hit: GeomapHit) = ActionRef(
    action = action,
    params = mapOf(
        "layer_id" to SpecValue.StringValue(hit.layerId),
        "feature_id" to SpecValue.StringValue(hit.featureId),
    ),
)

private fun viewportChangedAction(action: String, viewport: GeomapViewport) = ActionRef(
    action = action,
    params = mapOf(
        "lon" to SpecValue.NumberValue(viewport.lon),
        "lat" to SpecValue.NumberValue(viewport.lat),
        "zoom" to SpecValue.NumberValue(viewport.zoom.toDouble()),
    ),
)
